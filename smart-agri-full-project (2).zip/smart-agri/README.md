# 🌿 AgroSense 3D — Smart Agriculture Management System

A full-stack, production-grade Smart Farm Management System.

> **Two frontend modes in one project:**
> - **Standalone HTML** (`agrosense-3d.html`) — works immediately, no build step. Served by the Express backend.
> - **React SPA** — full component-based frontend with routing, auth context, socket.io client, and Recharts dashboards.

---

## 📁 Project Structure

```
smart-agri/
├── client/
│   ├── public/
│   │   ├── index.html              ← React app shell
│   │   └── agrosense-3d.html       ← ✅ Standalone HTML app (served by default)
│   ├── src/
│   │   ├── components/
│   │   │   ├── 3d/
│   │   │   │   └── FarmScene3D.js  ← Three.js 3D farm (React version)
│   │   │   └── common/
│   │   │       ├── Layout.js
│   │   │       ├── AlertBell.js
│   │   │       ├── SensorGauge.js
│   │   │       └── Toast.js
│   │   ├── pages/
│   │   │   ├── Dashboard.js
│   │   │   ├── CropManagement.js
│   │   │   ├── Weather.js
│   │   │   ├── Analytics.js
│   │   │   ├── FarmView.js
│   │   │   ├── Login.js
│   │   │   └── Register.js
│   │   ├── utils/
│   │   │   ├── api.js
│   │   │   └── sounds.js
│   │   ├── App.js
│   │   ├── index.js
│   │   └── index.css
│   └── package.json
│
├── server/
│   ├── config/db.js
│   ├── controllers/
│   │   ├── userController.js
│   │   ├── farmController.js
│   │   ├── cropController.js
│   │   ├── sensorController.js
│   │   ├── alertController.js
│   │   └── weatherController.js
│   ├── middleware/
│   │   ├── auth.js
│   │   └── errorHandler.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Farm.js
│   │   ├── Crop.js
│   │   ├── Sensor.js
│   │   └── Alert.js
│   ├── routes/
│   │   ├── userRoutes.js
│   │   ├── farmRoutes.js
│   │   ├── cropRoutes.js
│   │   ├── sensorRoutes.js
│   │   ├── alertRoutes.js
│   │   └── weatherRoutes.js
│   ├── index.js                    ← Express + Socket.IO entry point
│   ├── .env
│   └── package.json
│
└── README.md
```

---

## ⚡ Quick Start — Standalone Mode (Recommended)

This mode serves `agrosense-3d.html` directly. **No client-side build step needed.**

### 1. Prerequisites

- Node.js ≥ 18
- A MongoDB Atlas account (free tier works)

### 2. Configure environment

Edit `server/.env`:

```env
PORT=5000
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.mongodb.net/smart-agri
JWT_SECRET=your_secret_here
JWT_EXPIRE=7d
NODE_ENV=development
FRONTEND_MODE=standalone
```

### 3. Install server dependencies & run

```bash
cd server
npm install
npm run dev      # nodemon (auto-reload)
# or
npm start        # plain node
```

### 4. Open the app

```
http://localhost:5000/agrosense-3d.html
```

The HTML file is self-contained — it loads Three.js and Chart.js from CDN, simulates IoT sensor data in-browser, and calls the Express API for user auth and data persistence.

---

## 🚀 React SPA Mode

Use this mode if you want to extend the frontend with full React component architecture.

### 1. Set frontend mode in `.env`

```env
FRONTEND_MODE=react
```

### 2. Build the React client

```bash
cd client
npm install
npm run build
```

### 3. Start the server

```bash
cd ../server
npm run dev
```

The server will serve the React build from `client/build/`. Visit `http://localhost:5000`.

---

## 🗂️ API Reference

All routes are prefixed with `/api`.

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| POST | `/api/users/register` | — | Register new user |
| POST | `/api/users/login` | — | Login, returns JWT |
| GET | `/api/users/me` | ✅ | Get current user |
| GET | `/api/farms` | ✅ | List farms |
| POST | `/api/farms` | ✅ | Create farm |
| GET | `/api/farms/:id` | ✅ | Get farm details |
| PUT | `/api/farms/:id` | ✅ | Update farm |
| DELETE | `/api/farms/:id` | ✅ | Delete farm |
| GET | `/api/crops` | ✅ | List crops |
| POST | `/api/crops` | ✅ | Add crop |
| PUT | `/api/crops/:id` | ✅ | Update crop |
| DELETE | `/api/crops/:id` | ✅ | Remove crop |
| GET | `/api/sensors` | ✅ | List sensors |
| POST | `/api/sensors` | ✅ | Add sensor |
| GET | `/api/alerts` | ✅ | List alerts |
| PUT | `/api/alerts/:id/acknowledge` | ✅ | Ack alert |
| GET | `/api/weather` | ✅ | Current weather |
| GET | `/api/health` | — | Health check |

---

## 🔌 Real-time (Socket.IO)

The server emits `sensor-update` events every 10 seconds with:

```json
{
  "sensorId": "...",
  "type": "temperature",
  "value": 28.4,
  "timestamp": "2026-04-27T10:00:00.000Z"
}
```

Clients join a farm room to receive updates for that farm:

```js
socket.emit('join-farm', farmId);
socket.on('sensor-update', (data) => { /* update UI */ });
```

---

## 🌟 Standalone HTML Features (agrosense-3d.html)

| Feature | Details |
|---------|---------|
| 3D Farm | Three.js r128 — crops, drone, tractor, irrigation arms, day/night cycle, rain particles |
| IoT Simulation | Temperature, humidity, soil moisture, pH — real-time with configurable update intervals |
| AI Engine | Auto-irrigation decisions + disease prediction scoring |
| Analytics | Chart.js bar/line/doughnut charts, sparklines, sensor heatmap |
| Audio | WebAudio API — irrigation, rain, drone hum, ambient farm sounds |
| Auth | JWT-based login flow wired to `/api/users` |
| UI | Glassmorphism dark theme, Orbitron + Exo 2 fonts, fully responsive |

---

## ⚙️ Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `5000` | Server port |
| `MONGO_URI` | — | MongoDB connection string |
| `JWT_SECRET` | — | JWT signing secret |
| `JWT_EXPIRE` | `7d` | Token expiry |
| `NODE_ENV` | `development` | Environment |
| `FRONTEND_MODE` | `standalone` | `standalone` or `react` |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Standalone Frontend | Vanilla HTML/CSS/JS, Three.js r128, Chart.js 3 |
| React Frontend | React 18, React Three Fiber, Recharts, Socket.IO client |
| Backend | Node.js, Express 4, Socket.IO 4 |
| Database | MongoDB Atlas (Mongoose 8) |
| Auth | JWT + bcryptjs |
