/**
 * AlertBell.js - Topbar notification bell with dropdown
 */

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { alertAPI } from '../../utils/api';
import { playAlert } from '../../utils/sounds';

export default function AlertBell() {
  const { token } = useAuth();
  const [alerts, setAlerts]     = useState([]);
  const [open, setOpen]         = useState(false);
  const [loading, setLoading]   = useState(false);
  const dropRef                  = useRef(null);

  const unread = alerts.filter(a => !a.isRead).length;

  const fetchAlerts = async () => {
    setLoading(true);
    const data = await alertAPI.getAll(token);
    if (data.success) setAlerts(data.data.slice(0, 15));
    setLoading(false);
  };

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 30000); // refresh every 30s
    return () => clearInterval(interval);
  }, []); // eslint-disable-line

  // Close on outside click
  useEffect(() => {
    const handler = (e) => {
      if (dropRef.current && !dropRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleMarkRead = async (id) => {
    await alertAPI.markRead(token, id);
    setAlerts(p => p.map(a => a._id === id ? { ...a, isRead: true } : a));
  };

  const handleMarkAll = async () => {
    await alertAPI.markAllRead(token);
    setAlerts(p => p.map(a => ({ ...a, isRead: true })));
  };

  const typeIcon = { critical: '🔴', warning: '🟡', info: '🔵', success: '🟢' };

  return (
    <div ref={dropRef} style={{ position: 'relative' }}>
      <button
        style={styles.bell}
        onClick={() => { setOpen(p => !p); if (unread > 0) playAlert(); }}
      >
        🔔
        {unread > 0 && (
          <span style={styles.badge}>{unread > 9 ? '9+' : unread}</span>
        )}
      </button>

      {open && (
        <div style={styles.dropdown}>
          <div style={styles.dropHeader}>
            <span style={{ fontWeight: 700 }}>Notifications</span>
            {unread > 0 && (
              <button style={styles.markBtn} onClick={handleMarkAll}>
                Mark all read
              </button>
            )}
          </div>

          <div style={styles.list}>
            {loading && <div style={styles.empty}>Loading...</div>}
            {!loading && alerts.length === 0 && (
              <div style={styles.empty}>No alerts 🎉</div>
            )}
            {alerts.map(alert => (
              <div
                key={alert._id}
                style={{
                  ...styles.item,
                  background: alert.isRead ? 'transparent' : 'rgba(57,255,148,0.04)',
                }}
                onClick={() => handleMarkRead(alert._id)}
              >
                <span style={{ fontSize: '1rem' }}>{typeIcon[alert.type] || '⚪'}</span>
                <div style={{ flex: 1 }}>
                  <div style={styles.itemTitle}>{alert.title}</div>
                  <div style={styles.itemMsg}>{alert.message}</div>
                  <div style={styles.itemTime}>
                    {new Date(alert.createdAt).toLocaleString()}
                  </div>
                </div>
                {!alert.isRead && <span style={styles.unreadDot} />}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  bell: {
    position: 'relative',
    background: 'transparent',
    border: 'none',
    fontSize: '1.2rem',
    cursor: 'pointer',
    padding: '0.4rem',
    borderRadius: 'var(--radius-sm)',
  },
  badge: {
    position: 'absolute',
    top: '-2px', right: '-4px',
    background: 'var(--red)',
    color: '#fff',
    fontSize: '0.62rem',
    fontWeight: 700,
    borderRadius: '999px',
    padding: '0 4px',
    minWidth: '16px',
    textAlign: 'center',
    lineHeight: '16px',
    height: '16px',
  },
  dropdown: {
    position: 'absolute',
    right: 0, top: 'calc(100% + 8px)',
    width: '340px',
    background: 'var(--bg-card)',
    border: '1px solid var(--border-lit)',
    borderRadius: 'var(--radius-md)',
    boxShadow: 'var(--shadow-card)',
    zIndex: 500,
    overflow: 'hidden',
  },
  dropHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0.85rem 1rem',
    borderBottom: '1px solid var(--border)',
    fontSize: '0.9rem',
  },
  markBtn: {
    background: 'transparent',
    border: 'none',
    color: 'var(--green-mid)',
    fontSize: '0.8rem',
    cursor: 'pointer',
    fontFamily: 'var(--font-head)',
  },
  list: {
    maxHeight: '380px',
    overflowY: 'auto',
  },
  empty: {
    padding: '2rem',
    textAlign: 'center',
    color: 'var(--text-muted)',
    fontSize: '0.875rem',
  },
  item: {
    display: 'flex',
    gap: '0.75rem',
    padding: '0.75rem 1rem',
    borderBottom: '1px solid var(--border)',
    cursor: 'pointer',
    alignItems: 'flex-start',
    transition: 'background 0.15s',
  },
  itemTitle: { fontSize: '0.85rem', fontWeight: 700, color: 'var(--text-primary)' },
  itemMsg:   { fontSize: '0.78rem', color: 'var(--text-secondary)', marginTop: '0.2rem' },
  itemTime:  { fontSize: '0.7rem',  color: 'var(--text-muted)', marginTop: '0.3rem', fontFamily: 'var(--font-mono)' },
  unreadDot: {
    width: '7px', height: '7px',
    background: 'var(--green-bright)',
    borderRadius: '50%',
    flexShrink: 0,
    marginTop: '4px',
  },
};
