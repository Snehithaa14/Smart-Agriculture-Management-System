/**
 * Layout.js - Main app shell: Navbar + Sidebar + content area
 */

import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { playClick } from '../../utils/sounds';
import AlertBell from './AlertBell';

const navItems = [
  { to: '/',          icon: '⬡',  label: 'Dashboard'  },
  { to: '/crops',     icon: '🌾',  label: 'Crops'      },
  { to: '/weather',   icon: '🌤️', label: 'Weather'    },
  { to: '/analytics', icon: '📊',  label: 'Analytics'  },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogout = () => {
    playClick();
    logout();
    navigate('/login');
  };

  return (
    <div style={styles.shell}>
      {/* ── Sidebar ── */}
      <aside style={{ ...styles.sidebar, width: sidebarOpen ? '240px' : '68px' }}>
        {/* Logo */}
        <div style={styles.logo}>
          <span style={styles.logoIcon}>🌿</span>
          {sidebarOpen && <span style={styles.logoText}>AgriSmart</span>}
        </div>

        <div style={styles.divider} />

        {/* Nav items */}
        <nav style={styles.nav}>
          {navItems.map(({ to, icon, label }) => (
            <NavLink
              key={to}
              to={to}
              end={to === '/'}
              onClick={playClick}
              style={({ isActive }) => ({
                ...styles.navItem,
                ...(isActive ? styles.navItemActive : {}),
              })}
            >
              <span style={styles.navIcon}>{icon}</span>
              {sidebarOpen && <span style={styles.navLabel}>{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Bottom user section */}
        <div style={styles.sidebarBottom}>
          <div style={styles.divider} />
          {sidebarOpen && (
            <div style={styles.userInfo}>
              <div style={styles.avatar}>{user?.name?.[0]?.toUpperCase() || 'U'}</div>
              <div>
                <div style={styles.userName}>{user?.name}</div>
                <div style={styles.userRole}>{user?.role}</div>
              </div>
            </div>
          )}
          <button style={styles.logoutBtn} onClick={handleLogout} title="Logout">
            <span>⏻</span>
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* ── Main area ── */}
      <div style={styles.main}>
        {/* Topbar */}
        <header style={styles.topbar}>
          <button
            style={styles.menuBtn}
            onClick={() => { playClick(); setSidebarOpen(p => !p); }}
          >
            {sidebarOpen ? '✕' : '☰'}
          </button>

          <div style={styles.topbarRight}>
            <AlertBell />
            <div style={styles.topbarUser}>
              <span style={styles.liveDot} className="live-dot" />
              <span style={{ fontSize: '0.8rem', color: 'var(--text-secondary)' }}>Live</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main style={styles.content}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}

const styles = {
  shell: {
    display: 'flex',
    minHeight: '100vh',
    background: 'var(--bg-deep)',
  },
  sidebar: {
    background: 'var(--bg-card)',
    borderRight: '1px solid var(--border)',
    display: 'flex',
    flexDirection: 'column',
    padding: '1rem 0',
    transition: 'width 0.25s ease',
    overflow: 'hidden',
    flexShrink: 0,
    position: 'sticky',
    top: 0,
    height: '100vh',
    zIndex: 100,
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0.5rem 1.25rem 0.75rem',
  },
  logoIcon: { fontSize: '1.6rem', flexShrink: 0 },
  logoText: {
    fontFamily: 'var(--font-head)',
    fontWeight: 800,
    fontSize: '1.1rem',
    color: 'var(--green-bright)',
    letterSpacing: '-0.02em',
    whiteSpace: 'nowrap',
  },
  divider: {
    height: '1px',
    background: 'var(--border)',
    margin: '0.5rem 1rem',
  },
  nav: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.25rem',
    padding: '0.5rem 0.75rem',
    flex: 1,
  },
  navItem: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0.65rem 0.75rem',
    borderRadius: 'var(--radius-sm)',
    color: 'var(--text-secondary)',
    fontWeight: 500,
    fontSize: '0.9rem',
    textDecoration: 'none',
    transition: 'var(--transition)',
    whiteSpace: 'nowrap',
  },
  navItemActive: {
    background: 'rgba(34,197,94,0.12)',
    color: 'var(--green-bright)',
    fontWeight: 700,
  },
  navIcon: { fontSize: '1.1rem', flexShrink: 0, width: '20px', textAlign: 'center' },
  navLabel: {},
  sidebarBottom: {
    padding: '0 0.75rem',
  },
  userInfo: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0.75rem 0.5rem',
  },
  avatar: {
    width: '34px', height: '34px',
    background: 'var(--green-dim)',
    borderRadius: '50%',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontWeight: 800, fontSize: '0.85rem', color: '#000',
    flexShrink: 0,
  },
  userName: { fontSize: '0.85rem', fontWeight: 600, color: 'var(--text-primary)' },
  userRole: { fontSize: '0.72rem', color: 'var(--text-muted)', textTransform: 'capitalize' },
  logoutBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    width: '100%',
    padding: '0.6rem 0.75rem',
    background: 'transparent',
    border: 'none',
    color: 'var(--text-muted)',
    cursor: 'pointer',
    borderRadius: 'var(--radius-sm)',
    fontSize: '0.875rem',
    fontFamily: 'var(--font-head)',
    fontWeight: 500,
    transition: 'var(--transition)',
    marginTop: '0.25rem',
  },
  main: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    minWidth: 0,
  },
  topbar: {
    height: '64px',
    background: 'var(--bg-card)',
    borderBottom: '1px solid var(--border)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 1.5rem',
    position: 'sticky',
    top: 0,
    zIndex: 50,
  },
  menuBtn: {
    background: 'transparent',
    border: 'none',
    color: 'var(--text-secondary)',
    fontSize: '1.2rem',
    cursor: 'pointer',
    padding: '0.4rem',
    borderRadius: 'var(--radius-sm)',
    transition: 'var(--transition)',
  },
  topbarRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '1rem',
  },
  topbarUser: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.4rem',
  },
  liveDot: {},
  content: {
    flex: 1,
    padding: '2rem',
    overflowY: 'auto',
  },
};
