/**
 * SensorGauge.js - Animated SVG circular gauge for sensor readings
 */

import React from 'react';

export default function SensorGauge({ value = 0, min = 0, max = 100, unit = '%', label = '', color = '#22c55e', size = 120 }) {
  const radius = (size / 2) - 10;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.min(Math.max((value - min) / (max - min), 0), 1);
  const offset = circumference * (1 - pct * 0.75); // 270° arc

  const statusColor =
    pct > 0.85 ? '#ef4444' :
    pct > 0.65 ? '#f59e0b' :
    color;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.4rem' }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-135deg)' }}>
        {/* Track */}
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none"
          stroke="var(--border)"
          strokeWidth={8}
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
          strokeLinecap="round"
        />
        {/* Value arc */}
        <circle
          cx={size / 2} cy={size / 2} r={radius}
          fill="none"
          stroke={statusColor}
          strokeWidth={8}
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="gauge-ring"
          style={{ filter: `drop-shadow(0 0 6px ${statusColor}60)` }}
        />
        {/* Center value */}
        <text
          x={size / 2} y={size / 2 + 5}
          textAnchor="middle"
          style={{
            fill: 'var(--text-primary)',
            fontSize: size * 0.16,
            fontFamily: 'var(--font-mono)',
            fontWeight: 700,
            transform: `rotate(135deg)`,
            transformOrigin: `${size / 2}px ${size / 2}px`,
          }}
        >
          {typeof value === 'number' ? value.toFixed(1) : value}
          <tspan style={{ fontSize: size * 0.1, fill: 'var(--text-secondary)' }}>{unit}</tspan>
        </text>
      </svg>
      {label && (
        <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 }}>
          {label}
        </span>
      )}
    </div>
  );
}
