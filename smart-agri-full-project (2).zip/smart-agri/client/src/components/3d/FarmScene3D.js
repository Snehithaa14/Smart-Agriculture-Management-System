/**
 * FarmScene3D.js - 3D farm visualization using React Three Fiber
 * Shows crops as growing cylinders on a terrain grid
 */

import React, { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Text, Environment, Grid } from '@react-three/drei';
import * as THREE from 'three';

// Individual crop plant 3D object
function CropPlant({ position, color, height, label, status }) {
  const meshRef = useRef();
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5 + position[0]) * 0.05;
      if (hovered) {
        meshRef.current.scale.y = THREE.MathUtils.lerp(meshRef.current.scale.y, 1.15, 0.1);
      } else {
        meshRef.current.scale.y = THREE.MathUtils.lerp(meshRef.current.scale.y, 1.0, 0.1);
      }
    }
  });

  const plantColor = status === 'harvested' ? '#8B6914' :
                     status === 'failed'    ? '#6b2d2d' :
                     color || '#22c55e';

  return (
    <group position={position}>
      {/* Soil mound */}
      <mesh position={[0, 0.05, 0]}>
        <cylinderGeometry args={[0.35, 0.5, 0.1, 8]} />
        <meshStandardMaterial color="#5a3a1a" roughness={1} />
      </mesh>

      {/* Stem */}
      <mesh position={[0, height / 2 + 0.1, 0]} ref={meshRef}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <cylinderGeometry args={[0.05, 0.08, height, 6]} />
        <meshStandardMaterial color="#4a7c3f" roughness={0.8} />
      </mesh>

      {/* Crown / leaves */}
      <mesh position={[0, height + 0.15, 0]}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
      >
        <sphereGeometry args={[0.28, 8, 8]} />
        <meshStandardMaterial
          color={plantColor}
          roughness={0.6}
          emissive={hovered ? plantColor : '#000'}
          emissiveIntensity={hovered ? 0.3 : 0}
        />
      </mesh>

      {/* Label */}
      {hovered && (
        <Text
          position={[0, height + 0.65, 0]}
          fontSize={0.18}
          color="white"
          anchorX="center"
          anchorY="middle"
          outlineWidth={0.02}
          outlineColor="black"
        >
          {label}
        </Text>
      )}
    </group>
  );
}

// Animated water/irrigation stream
function IrrigationLine({ from, to }) {
  const ref = useRef();
  useFrame((state) => {
    if (ref.current) {
      ref.current.material.dashOffset -= 0.02;
    }
  });
  const points = [new THREE.Vector3(...from), new THREE.Vector3(...to)];
  const geometry = new THREE.BufferGeometry().setFromPoints(points);

  return (
    <line ref={ref} geometry={geometry}>
      <lineDashedMaterial color="#06b6d4" dashSize={0.2} gapSize={0.15} linewidth={1} />
    </line>
  );
}

// Farm ground
function Terrain() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
      <planeGeometry args={[16, 16, 32, 32]} />
      <meshStandardMaterial color="#1a3a0f" roughness={1} metalness={0} />
    </mesh>
  );
}

// Animated sun
function Sun() {
  const ref = useRef();
  useFrame((state) => {
    if (ref.current) {
      ref.current.position.x = Math.sin(state.clock.elapsedTime * 0.1) * 8;
      ref.current.position.y = 6 + Math.sin(state.clock.elapsedTime * 0.05) * 2;
    }
  });
  return (
    <mesh ref={ref} position={[5, 7, -5]}>
      <sphereGeometry args={[0.4, 16, 16]} />
      <meshStandardMaterial color="#fde68a" emissive="#fbbf24" emissiveIntensity={1} />
      <pointLight color="#fde68a" intensity={2} distance={20} />
    </mesh>
  );
}

export default function FarmScene3D({ crops = [] }) {
  // Generate grid positions for crops
  const positions = crops.slice(0, 12).map((crop, i) => {
    const col = i % 4;
    const row = Math.floor(i / 4);
    return [(col - 1.5) * 3.5, 0, (row - 1) * 3.5];
  });

  const cropColors = {
    planted: '#3b82f6',
    growing: '#22c55e',
    flowering: '#ec4899',
    harvested: '#f59e0b',
    failed: '#ef4444',
  };

  const cropHeights = {
    planted: 0.3,
    growing: 0.7,
    flowering: 1.0,
    harvested: 0.5,
    failed: 0.2,
  };

  return (
    <div style={{ width: '100%', height: '380px', borderRadius: 'var(--radius-md)', overflow: 'hidden', border: '1px solid var(--border)' }}>
      <Canvas
        camera={{ position: [8, 8, 8], fov: 50 }}
        shadows
        style={{ background: 'linear-gradient(180deg, #0a1628 0%, #0d2b1a 100%)' }}
      >
        {/* Lighting */}
        <ambientLight intensity={0.4} />
        <directionalLight position={[5, 10, 5]} intensity={1.2} castShadow />
        <pointLight position={[-5, 5, -5]} color="#22c55e" intensity={0.5} />

        <Sun />

        {/* Terrain */}
        <Terrain />

        {/* Grid overlay */}
        <Grid
          position={[0, 0.01, 0]}
          args={[16, 16]}
          cellSize={1}
          cellThickness={0.3}
          cellColor="#1e3a1a"
          sectionSize={4}
          sectionThickness={0.8}
          sectionColor="#2d5a2d"
          fadeDistance={20}
          fadeStrength={1}
        />

        {/* Crops */}
        {crops.slice(0, 12).map((crop, i) => (
          <CropPlant
            key={crop._id || i}
            position={positions[i]}
            color={cropColors[crop.status]}
            height={cropHeights[crop.status] || 0.7}
            label={crop.name}
            status={crop.status}
          />
        ))}

        {/* Irrigation lines between crops */}
        {positions.length > 1 && positions.slice(0, -1).map((pos, i) => (
          <IrrigationLine key={i} from={[pos[0], 0.05, pos[2]]} to={[positions[i + 1][0], 0.05, positions[i + 1][2]]} />
        ))}

        {/* Empty state */}
        {crops.length === 0 && (
          <Text position={[0, 1, 0]} fontSize={0.5} color="#4a6680" anchorX="center">
            No crops planted yet
          </Text>
        )}

        <OrbitControls
          enablePan={false}
          maxPolarAngle={Math.PI / 2.2}
          minDistance={5}
          maxDistance={18}
          autoRotate
          autoRotateSpeed={0.4}
        />
        <fog attach="fog" args={['#0a1628', 15, 30]} />
      </Canvas>
    </div>
  );
}
