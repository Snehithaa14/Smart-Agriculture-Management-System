/**
 * App.js - Root component with React Router setup
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

// Pages
import Login        from './pages/Login';
import Register     from './pages/Register';
import Dashboard    from './pages/Dashboard';
import CropMgmt     from './pages/CropManagement';
import WeatherPage  from './pages/Weather';
import Analytics    from './pages/Analytics';
import FarmView     from './pages/FarmView';

// Layout
import Layout from './components/common/Layout';

import './index.css';

// Protected route wrapper
const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) return <div className="splash-loader"><div className="leaf-spin">🌿</div></div>;
  return user ? children : <Navigate to="/login" replace />;
};

const AppRoutes = () => (
  <Routes>
    <Route path="/login"    element={<Login />} />
    <Route path="/register" element={<Register />} />
    <Route path="/" element={
      <ProtectedRoute>
        <Layout />
      </ProtectedRoute>
    }>
      <Route index                element={<Dashboard />} />
      <Route path="crops"         element={<CropMgmt />} />
      <Route path="weather"       element={<WeatherPage />} />
      <Route path="analytics"     element={<Analytics />} />
      <Route path="farm/:id"      element={<FarmView />} />
    </Route>
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
);

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <AppRoutes />
      </Router>
    </AuthProvider>
  );
}
