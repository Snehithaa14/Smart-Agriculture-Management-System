/**
 * Sound Effects Utility
 * Uses Web Audio API to generate programmatic sound effects (no files needed)
 */

const AudioContext = window.AudioContext || window.webkitAudioContext;
let ctx = null;

const getCtx = () => {
  if (!ctx) ctx = new AudioContext();
  return ctx;
};

// Soft click sound
export const playClick = () => {
  try {
    const ac  = getCtx();
    const osc = ac.createOscillator();
    const g   = ac.createGain();
    osc.connect(g);
    g.connect(ac.destination);
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, ac.currentTime);
    osc.frequency.exponentialRampToValueAtTime(400, ac.currentTime + 0.1);
    g.gain.setValueAtTime(0.15, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.15);
    osc.start();
    osc.stop(ac.currentTime + 0.15);
  } catch { /* ignore */ }
};

// Success chime
export const playSuccess = () => {
  try {
    const ac   = getCtx();
    const freqs = [523, 659, 784];  // C, E, G
    freqs.forEach((freq, i) => {
      const osc = ac.createOscillator();
      const g   = ac.createGain();
      osc.connect(g);
      g.connect(ac.destination);
      osc.type = 'sine';
      osc.frequency.value = freq;
      g.gain.setValueAtTime(0, ac.currentTime + i * 0.12);
      g.gain.linearRampToValueAtTime(0.12, ac.currentTime + i * 0.12 + 0.05);
      g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + i * 0.12 + 0.3);
      osc.start(ac.currentTime + i * 0.12);
      osc.stop(ac.currentTime + i * 0.12 + 0.35);
    });
  } catch { /* ignore */ }
};

// Alert / warning buzz
export const playAlert = () => {
  try {
    const ac  = getCtx();
    const osc = ac.createOscillator();
    const g   = ac.createGain();
    osc.connect(g);
    g.connect(ac.destination);
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, ac.currentTime);
    osc.frequency.setValueAtTime(180, ac.currentTime + 0.1);
    osc.frequency.setValueAtTime(220, ac.currentTime + 0.2);
    g.gain.setValueAtTime(0.08, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.3);
    osc.start();
    osc.stop(ac.currentTime + 0.3);
  } catch { /* ignore */ }
};

// Soft error tone
export const playError = () => {
  try {
    const ac  = getCtx();
    const osc = ac.createOscillator();
    const g   = ac.createGain();
    osc.connect(g);
    g.connect(ac.destination);
    osc.type = 'square';
    osc.frequency.setValueAtTime(200, ac.currentTime);
    osc.frequency.exponentialRampToValueAtTime(100, ac.currentTime + 0.25);
    g.gain.setValueAtTime(0.08, ac.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.3);
    osc.start();
    osc.stop(ac.currentTime + 0.3);
  } catch { /* ignore */ }
};
