/**
 * API Utility
 * Centralized fetch helpers for all API endpoints
 */

const BASE = '/api';

export const apiFetch = async (url, token, options = {}) => {
  const res = await fetch(`${BASE}${url}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  });
  return res.json();
};

// Farms
export const farmAPI = {
  getAll:  (tk)         => apiFetch('/farms', tk),
  getOne:  (tk, id)     => apiFetch(`/farms/${id}`, tk),
  create:  (tk, data)   => apiFetch('/farms', tk, { method: 'POST', body: JSON.stringify(data) }),
  update:  (tk, id, d)  => apiFetch(`/farms/${id}`, tk, { method: 'PUT', body: JSON.stringify(d) }),
  delete:  (tk, id)     => apiFetch(`/farms/${id}`, tk, { method: 'DELETE' }),
};

// Crops
export const cropAPI = {
  getAll:   (tk, farmId) => apiFetch(`/crops${farmId ? `?farmId=${farmId}` : ''}`, tk),
  getOne:   (tk, id)     => apiFetch(`/crops/${id}`, tk),
  create:   (tk, data)   => apiFetch('/crops', tk, { method: 'POST', body: JSON.stringify(data) }),
  update:   (tk, id, d)  => apiFetch(`/crops/${id}`, tk, { method: 'PUT', body: JSON.stringify(d) }),
  delete:   (tk, id)     => apiFetch(`/crops/${id}`, tk, { method: 'DELETE' }),
};

// Sensors
export const sensorAPI = {
  getAll:     (tk, farmId) => apiFetch(`/sensors${farmId ? `?farmId=${farmId}` : ''}`, tk),
  create:     (tk, data)   => apiFetch('/sensors', tk, { method: 'POST', body: JSON.stringify(data) }),
  addReading: (tk, id, v)  => apiFetch(`/sensors/${id}/readings`, tk, { method: 'POST', body: JSON.stringify({ value: v }) }),
  delete:     (tk, id)     => apiFetch(`/sensors/${id}`, tk, { method: 'DELETE' }),
};

// Alerts
export const alertAPI = {
  getAll:    (tk)     => apiFetch('/alerts', tk),
  markRead:  (tk, id) => apiFetch(`/alerts/${id}/read`, tk, { method: 'PUT' }),
  markAllRead: (tk)   => apiFetch('/alerts/read-all', tk, { method: 'PUT' }),
  resolve:   (tk, id) => apiFetch(`/alerts/${id}/resolve`, tk, { method: 'PUT' }),
  delete:    (tk, id) => apiFetch(`/alerts/${id}`, tk, { method: 'DELETE' }),
};

// Weather
export const weatherAPI = {
  getCurrent: (tk, location) => apiFetch(`/weather?location=${location || 'Farm'}`, tk),
};

export default apiFetch;
