/**
 * Dashboard.js - Main farm overview with stats, 3D scene, sensors, alerts
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { farmAPI, cropAPI, alertAPI, sensorAPI } from '../utils/api';
import { playClick, playSuccess, playError } from '../utils/sounds';
import FarmScene3D from '../components/3d/FarmScene3D';
import SensorGauge from '../components/common/SensorGauge';
import io from 'socket.io-client';

const socket = io('http://localhost:5000');

export default function Dashboard() {
  const { user, token } = useAuth();
  const [farms, setFarms]       = useState([]);
  const [crops, setCrops]       = useState([]);
  const [sensors, setSensors]   = useState([]);
  const [alerts, setAlerts]     = useState([]);
  const [loading, setLoading]   = useState(true);
  const [activeFarm, setActiveFarm] = useState(null);

  // Modal for creating farm
  const [showFarmModal, setShowFarmModal] = useState(false);
  const [farmForm, setFarmForm] = useState({ name: '', location: { address: '' }, size: { value: '' }, soilType: 'loamy' });
  const [saving, setSaving]     = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [fRes, cRes, aRes] = await Promise.all([
        farmAPI.getAll(token),
        cropAPI.getAll(token),
        alertAPI.getAll(token),
      ]);
      if (fRes.success) {
        setFarms(fRes.data);
        if (fRes.data.length > 0 && !activeFarm) setActiveFarm(fRes.data[0]._id);
      }
      if (cRes.success) setCrops(cRes.data);
      if (aRes.success) setAlerts(aRes.data);

      // Load sensors for first farm
      if (fRes.data?.[0]) {
        const sRes = await sensorAPI.getAll(token, fRes.data[0]._id);
        if (sRes.success) setSensors(sRes.data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [token]); // eslint-disable-line

  useEffect(() => { load(); }, [load]);

  // Socket.IO real-time updates
  useEffect(() => {
    if (activeFarm) {
      socket.emit('join-farm', activeFarm);
      socket.on('sensor-update', (update) => {
        setSensors(prev => prev.map(s =>
          s._id === update.sensorId ? { ...s, currentValue: update.value } : s
        ));
      });
      socket.on('new-alert', (alert) => {
        setAlerts(prev => [alert, ...prev]);
        playError();
      });
    }
    return () => { socket.off('sensor-update'); socket.off('new-alert'); };
  }, [activeFarm]);

  const handleCreateFarm = async (e) => {
    e.preventDefault();
    playClick();
    setSaving(true);
    try {
      const res = await farmAPI.create(token, farmForm);
      if (res.success) {
        playSuccess();
        setFarms(p => [...p, res.data]);
        setActiveFarm(res.data._id);
        setShowFarmModal(false);
        setFarmForm({ name: '', location: { address: '' }, size: { value: '' }, soilType: 'loamy' });
      }
    } catch { playError(); }
    finally { setSaving(false); }
  };

  const farmCrops = crops.filter(c => c.farm?._id === activeFarm || c.farm === activeFarm);
  const unreadAlerts = alerts.filter(a => !a.isRead).length;

  const stats = [
    { label: 'Total Farms',    value: farms.length,      icon: '🏡', color: 'var(--green-bright)', sub: 'registered' },
    { label: 'Active Crops',   value: farmCrops.filter(c => c.status !== 'harvested').length, icon: '🌾', color: 'var(--cyan)', sub: 'in the field' },
    { label: 'Live Sensors',   value: sensors.filter(s => s.isActive).length, icon: '📡', color: 'var(--blue)', sub: 'online' },
    { label: 'Unread Alerts',  value: unreadAlerts,       icon: '🔔', color: unreadAlerts > 0 ? 'var(--red)' : 'var(--green-mid)', sub: 'notifications' },
  ];

  if (loading) return (
    <div className="flex-center" style={{ minHeight: '60vh' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', animation: 'spin 1s linear infinite' }}>🌿</div>
        <div style={{ color: 'var(--text-muted)', marginTop: '1rem' }}>Loading your farm...</div>
      </div>
    </div>
  );

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">
            Good {new Date().getHours() < 12 ? 'Morning' : new Date().getHours() < 17 ? 'Afternoon' : 'Evening'}, {user?.name?.split(' ')[0]} 👋
          </h1>
          <p className="page-subtitle">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <button className="btn btn-primary" onClick={() => { playClick(); setShowFarmModal(true); }}>
          + Add Farm
        </button>
      </div>

      {/* Stats row */}
      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <span className="stat-icon">{s.icon}</span>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            <div className="stat-sub">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Farm selector */}
      {farms.length > 0 && (
        <div style={styles.farmTabs}>
          {farms.map(f => (
            <button
              key={f._id}
              className={`btn ${activeFarm === f._id ? 'btn-primary' : 'btn-ghost'}`}
              onClick={() => { playClick(); setActiveFarm(f._id); }}
            >
              🏡 {f.name}
            </button>
          ))}
        </div>
      )}

      {/* No farms empty state */}
      {farms.length === 0 && (
        <div style={styles.emptyState}>
          <div style={{ fontSize: '4rem' }}>🌱</div>
          <h3 style={{ fontSize: '1.3rem', fontWeight: 700, marginBottom: '0.5rem' }}>No farms yet</h3>
          <p style={{ color: 'var(--text-secondary)', marginBottom: '1.5rem' }}>Add your first farm to get started</p>
          <button className="btn btn-primary btn-lg" onClick={() => { playClick(); setShowFarmModal(true); }}>
            + Create Your First Farm
          </button>
        </div>
      )}

      {/* Main content grid */}
      {farms.length > 0 && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: '1.5rem' }}>
          {/* Left column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* 3D Farm View */}
            <div className="card" style={{ padding: '1rem' }}>
              <div className="flex-between" style={{ marginBottom: '0.75rem' }}>
                <h3 style={styles.sectionTitle}>🌍 3D Farm View</h3>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span className="live-dot" />
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Live</span>
                </div>
              </div>
              <FarmScene3D crops={farmCrops} />
            </div>

            {/* Sensors */}
            <div className="card">
              <div className="flex-between" style={{ marginBottom: '1rem' }}>
                <h3 style={styles.sectionTitle}>📡 Sensor Readings</h3>
                <span className="badge badge-green">{sensors.filter(s => s.isActive).length} Online</span>
              </div>
              {sensors.length === 0 ? (
                <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>No sensors configured for this farm.</p>
              ) : (
                <div style={{ display: 'flex', gap: '2rem', flexWrap: 'wrap', justifyContent: 'center' }}>
                  {sensors.slice(0, 6).map(s => (
                    <SensorGauge
                      key={s._id}
                      value={s.currentValue}
                      unit={s.unit}
                      label={s.name}
                      min={s.type === 'temperature' ? 0 : 0}
                      max={s.type === 'temperature' ? 50 : 100}
                      color={s.type === 'temperature' ? '#f59e0b' : s.type === 'humidity' ? '#06b6d4' : '#22c55e'}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Right column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {/* Recent crops */}
            <div className="card">
              <div className="flex-between" style={{ marginBottom: '1rem' }}>
                <h3 style={styles.sectionTitle}>🌾 Crops</h3>
                <Link to="/crops" className="btn btn-ghost btn-sm" onClick={playClick}>View All →</Link>
              </div>
              {farmCrops.length === 0 ? (
                <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>No crops planted yet.</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {farmCrops.slice(0, 5).map(crop => (
                    <div key={crop._id} style={styles.cropRow}>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '0.9rem' }}>{crop.name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{crop.variety}</div>
                      </div>
                      <span className={`badge badge-${statusBadge(crop.status)}`}>{crop.status}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recent alerts */}
            <div className="card">
              <div className="flex-between" style={{ marginBottom: '1rem' }}>
                <h3 style={styles.sectionTitle}>🔔 Recent Alerts</h3>
                {unreadAlerts > 0 && (
                  <span className="badge badge-red">{unreadAlerts} new</span>
                )}
              </div>
              {alerts.length === 0 ? (
                <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>All clear — no alerts!</p>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                  {alerts.slice(0, 5).map(alert => (
                    <div key={alert._id} className={`alert-item ${alert.type} ${!alert.isRead ? 'unread' : ''}`}>
                      <span>{alertIcon(alert.type)}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: '0.85rem', fontWeight: 600 }}>{alert.title}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)', marginTop: '0.1rem' }}>
                          {alert.message.substring(0, 60)}...
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Create Farm Modal */}
      {showFarmModal && (
        <div className="modal-overlay" onClick={() => setShowFarmModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2 className="modal-title">🏡 Add New Farm</h2>
            <form onSubmit={handleCreateFarm}>
              <div className="form-group">
                <label className="form-label">Farm Name</label>
                <input type="text" className="form-input" placeholder="e.g. Green Valley Farm"
                  value={farmForm.name}
                  onChange={e => setFarmForm(p => ({ ...p, name: e.target.value }))} required />
              </div>
              <div className="form-group">
                <label className="form-label">Address</label>
                <input type="text" className="form-input" placeholder="Village, District, State"
                  value={farmForm.location.address}
                  onChange={e => setFarmForm(p => ({ ...p, location: { address: e.target.value } }))} required />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Size (acres)</label>
                  <input type="number" className="form-input" placeholder="10"
                    value={farmForm.size.value}
                    onChange={e => setFarmForm(p => ({ ...p, size: { value: e.target.value } }))} required />
                </div>
                <div className="form-group">
                  <label className="form-label">Soil Type</label>
                  <select className="form-select"
                    value={farmForm.soilType}
                    onChange={e => setFarmForm(p => ({ ...p, soilType: e.target.value }))}>
                    {['clay','sandy','loamy','silty','peaty','chalky','mixed'].map(t => (
                      <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end', marginTop: '0.5rem' }}>
                <button type="button" className="btn btn-ghost" onClick={() => { playClick(); setShowFarmModal(false); }}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>
                  {saving ? <><span className="spinner" /> Saving...</> : '+ Create Farm'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

const statusBadge = (s) => ({ planted: 'blue', growing: 'green', flowering: 'cyan', harvested: 'amber', failed: 'red' }[s] || 'blue');
const alertIcon   = (t) => ({ critical: '🔴', warning: '🟡', info: '🔵', success: '🟢' }[t] || '⚪');

const styles = {
  sectionTitle: { fontSize: '1rem', fontWeight: 700, color: 'var(--text-primary)' },
  farmTabs: { display: 'flex', gap: '0.5rem', marginBottom: '1.5rem', flexWrap: 'wrap' },
  emptyState: {
    textAlign: 'center',
    padding: '4rem 2rem',
    background: 'var(--bg-card)',
    border: '1px dashed var(--border-lit)',
    borderRadius: 'var(--radius-lg)',
  },
  cropRow: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0.6rem 0.75rem',
    background: 'var(--bg-panel)',
    borderRadius: 'var(--radius-sm)',
  },
};
