/**
 * Register.js - New user registration page
 */

import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { playClick, playSuccess, playError } from '../utils/sounds';

export default function Register() {
  const { register, user } = useAuth();
  const navigate = useNavigate();

  const [form, setForm]       = useState({ name: '', email: '', password: '', confirmPassword: '', role: 'farmer' });
  const [errors, setErrors]   = useState({});
  const [loading, setLoading] = useState(false);
  const [apiErr, setApiErr]   = useState('');

  useEffect(() => { if (user) navigate('/'); }, [user, navigate]);

  const validate = () => {
    const errs = {};
    if (!form.name.trim())               errs.name    = 'Name is required';
    if (!form.email)                     errs.email   = 'Email is required';
    if (!form.password)                  errs.password = 'Password is required';
    if (form.password.length < 6)        errs.password = 'Minimum 6 characters';
    if (form.password !== form.confirmPassword) errs.confirmPassword = 'Passwords do not match';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    playClick();
    if (!validate()) { playError(); return; }
    setLoading(true); setApiErr('');
    try {
      await register(form.name, form.email, form.password, form.role);
      playSuccess();
      navigate('/');
    } catch (err) {
      playError();
      setApiErr(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  const set = (field) => (e) => setForm(p => ({ ...p, [field]: e.target.value }));

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.logo}>
          <span style={{ fontSize: '2rem' }}>🌿</span>
          <span style={styles.logoText}>AgriSmart</span>
        </div>

        <h2 style={styles.title}>Create account</h2>
        <p style={styles.subtitle}>Start managing your farm intelligently</p>

        {apiErr && (
          <div style={styles.apiError}>⚠️ {apiErr}</div>
        )}

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input type="text" className={`form-input${errors.name ? ' error' : ''}`}
              placeholder="John Farmer" value={form.name} onChange={set('name')} />
            {errors.name && <span className="form-error">{errors.name}</span>}
          </div>

          <div className="form-group">
            <label className="form-label">Email</label>
            <input type="email" className={`form-input${errors.email ? ' error' : ''}`}
              placeholder="you@farm.com" value={form.email} onChange={set('email')} />
            {errors.email && <span className="form-error">{errors.email}</span>}
          </div>

          <div className="grid-2">
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" className={`form-input${errors.password ? ' error' : ''}`}
                placeholder="Min 6 chars" value={form.password} onChange={set('password')} />
              {errors.password && <span className="form-error">{errors.password}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Confirm Password</label>
              <input type="password" className={`form-input${errors.confirmPassword ? ' error' : ''}`}
                placeholder="Repeat password" value={form.confirmPassword} onChange={set('confirmPassword')} />
              {errors.confirmPassword && <span className="form-error">{errors.confirmPassword}</span>}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Role</label>
            <select className="form-select" value={form.role} onChange={set('role')}>
              <option value="farmer">Farmer</option>
              <option value="analyst">Analyst</option>
              <option value="admin">Admin</option>
            </select>
          </div>

          <button type="submit" className="btn btn-primary w-full btn-lg" disabled={loading} style={{ marginTop: '0.5rem' }}>
            {loading ? <><span className="spinner" /> Creating account...</> : 'Create Account →'}
          </button>
        </form>

        <p style={styles.switchText}>
          Already have an account? <Link to="/login">Sign in</Link>
        </p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: '100vh',
    background: 'radial-gradient(ellipse at 20% 50%, rgba(22,163,74,0.08) 0%, transparent 60%), var(--bg-deep)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '1rem',
  },
  card: {
    background: 'var(--bg-card)',
    border: '1px solid var(--border-lit)',
    borderRadius: 'var(--radius-lg)',
    padding: '2.5rem',
    width: '100%',
    maxWidth: '480px',
    boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    marginBottom: '2rem',
  },
  logoText: {
    fontWeight: 800,
    fontSize: '1.3rem',
    color: 'var(--green-bright)',
    fontFamily: 'var(--font-head)',
  },
  title:    { fontSize: '1.5rem', fontWeight: 800, marginBottom: '0.25rem' },
  subtitle: { fontSize: '0.875rem', color: 'var(--text-secondary)', marginBottom: '1.75rem' },
  apiError: {
    background: 'rgba(239,68,68,0.1)',
    border: '1px solid rgba(239,68,68,0.3)',
    borderRadius: 'var(--radius-sm)',
    padding: '0.75rem 1rem',
    color: 'var(--red)',
    fontSize: '0.875rem',
    marginBottom: '1rem',
  },
  switchText: {
    textAlign: 'center',
    fontSize: '0.875rem',
    color: 'var(--text-secondary)',
    marginTop: '1.5rem',
  },
};
