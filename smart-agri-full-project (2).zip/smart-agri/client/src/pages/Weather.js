/**
 * Weather.js - Weather dashboard with current conditions, forecast, and hourly chart
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { weatherAPI } from '../utils/api';
import { playClick } from '../utils/sounds';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area,
} from 'recharts';

export default function WeatherPage() {
  const { token } = useAuth();
  const [weather, setWeather]   = useState(null);
  const [loading, setLoading]   = useState(true);
  const [location, setLocation] = useState('My Farm');
  const [searchVal, setSearch]  = useState('');
  const [lastFetch, setLastFetch] = useState(null);

  const fetchWeather = useCallback(async (loc) => {
    setLoading(true);
    try {
      const res = await weatherAPI.getCurrent(token, loc || location);
      if (res.success) {
        setWeather(res.data);
        setLastFetch(new Date());
      }
    } finally {
      setLoading(false);
    }
  }, [token, location]);

  useEffect(() => { fetchWeather(location); }, []); // eslint-disable-line

  // Auto-refresh every 60 seconds
  useEffect(() => {
    const timer = setInterval(() => fetchWeather(location), 60000);
    return () => clearInterval(timer);
  }, [fetchWeather, location]);

  const handleSearch = (e) => {
    e.preventDefault();
    playClick();
    setLocation(searchVal || 'My Farm');
    fetchWeather(searchVal || 'My Farm');
  };

  const uvLabel = (uv) => {
    if (uv <= 2) return { label: 'Low',       color: 'var(--green-mid)' };
    if (uv <= 5) return { label: 'Moderate',  color: 'var(--amber)' };
    if (uv <= 7) return { label: 'High',       color: '#f97316' };
    return             { label: 'Very High',  color: 'var(--red)' };
  };

  const farmAdvice = (cond, temp) => {
    if (!cond) return '';
    if (cond.includes('Rain') || cond.includes('Thunder')) return '⚠️ Delay irrigation. Check drainage systems. Protect sensitive crops.';
    if (temp > 35) return '🌡️ High heat alert! Increase irrigation frequency. Consider shade nets for vegetables.';
    if (temp < 10) return '❄️ Cold conditions. Protect frost-sensitive crops. Reduce irrigation.';
    return '✅ Good conditions for field work. Optimal growing weather.';
  };

  if (loading && !weather) return (
    <div className="flex-center" style={{ minHeight: '60vh' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: '3rem', animation: 'spin 1s linear infinite' }}>🌀</div>
        <div style={{ color: 'var(--text-muted)', marginTop: '1rem' }}>Fetching weather data...</div>
      </div>
    </div>
  );

  const cur = weather?.current;
  const uv  = uvLabel(cur?.uvIndex);

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">🌤️ Weather Intelligence</h1>
          <p className="page-subtitle">
            Last updated: {lastFetch ? lastFetch.toLocaleTimeString() : '—'}
            {' '}<span className="live-dot" style={{ marginLeft: '0.5rem' }} />
          </p>
        </div>
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: '0.5rem' }}>
          <input
            className="form-input"
            placeholder="Enter location..."
            value={searchVal}
            onChange={e => setSearch(e.target.value)}
            style={{ width: '200px' }}
          />
          <button type="submit" className="btn btn-primary">Search</button>
          <button type="button" className="btn btn-outline" onClick={() => fetchWeather(location)}>
            🔄 Refresh
          </button>
        </form>
      </div>

      {cur && (
        <>
          {/* Farm advice banner */}
          <div style={styles.adviceBanner}>
            <span style={{ fontSize: '1.1rem' }}>🌾</span>
            <span style={{ fontSize: '0.9rem' }}>{farmAdvice(cur.condition, cur.temperature)}</span>
          </div>

          {/* Current weather hero */}
          <div style={styles.heroCard}>
            <div style={styles.heroLeft}>
              <div style={styles.weatherIcon}>{cur.icon}</div>
              <div>
                <div style={styles.tempBig}>{cur.temperature}°C</div>
                <div style={styles.feelsLike}>Feels like {cur.feelsLike}°C</div>
                <div style={styles.condition}>{cur.condition}</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.25rem' }}>
                  📍 {cur.location}
                </div>
              </div>
            </div>
            <div style={styles.heroStats}>
              {[
                { label: 'Humidity',    value: `${cur.humidity}%`,         icon: '💧' },
                { label: 'Wind Speed',  value: `${cur.windSpeed} km/h`,    icon: '💨' },
                { label: 'Rainfall',    value: `${cur.rainfall} mm`,        icon: '🌧️' },
                { label: 'UV Index',    value: `${cur.uvIndex} — ${uv.label}`, icon: '☀️', color: uv.color },
                { label: 'Pressure',    value: `${cur.pressure} hPa`,      icon: '⏱️' },
                { label: 'Visibility',  value: `${cur.visibility} km`,     icon: '👁️' },
              ].map(item => (
                <div key={item.label} style={styles.heroStat}>
                  <span style={styles.heroStatIcon}>{item.icon}</span>
                  <div>
                    <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{item.label}</div>
                    <div style={{ fontWeight: 700, fontSize: '0.95rem', color: item.color || 'var(--text-primary)', fontFamily: 'var(--font-mono)' }}>{item.value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Hourly temperature chart */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <h3 style={styles.sectionTitle}>📈 24-Hour Temperature Forecast</h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={weather.hourly} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="tempGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%"  stopColor="#22c55e" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="hour" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} interval={3} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} unit="°" />
                <Tooltip
                  contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-lit)', borderRadius: '8px' }}
                  labelStyle={{ color: 'var(--text-primary)' }}
                  itemStyle={{ color: 'var(--green-bright)' }}
                />
                <Area type="monotone" dataKey="temp" stroke="#22c55e" strokeWidth={2} fill="url(#tempGrad)" name="Temp °C" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* 7-day forecast */}
          <div className="card" style={{ marginBottom: '1.5rem' }}>
            <h3 style={styles.sectionTitle}>📅 7-Day Forecast</h3>
            <div style={styles.forecastGrid}>
              {weather.forecast.map((day, i) => (
                <div key={i} style={{ ...styles.forecastDay, background: i === 0 ? 'rgba(34,197,94,0.08)' : 'var(--bg-panel)', borderColor: i === 0 ? 'var(--green-dim)' : 'var(--border)' }}>
                  <div style={styles.forecastDayName}>{i === 0 ? 'Today' : day.day}</div>
                  <div style={{ fontSize: '1.8rem', margin: '0.5rem 0' }}>{day.icon}</div>
                  <div style={styles.forecastCond}>{day.condition}</div>
                  <div style={styles.forecastTemps}>
                    <span style={{ color: 'var(--red)', fontWeight: 700 }}>{day.high}°</span>
                    <span style={{ color: 'var(--text-muted)' }}>/</span>
                    <span style={{ color: 'var(--blue)' }}>{day.low}°</span>
                  </div>
                  <div style={styles.rainChance}>
                    💧 {day.rainChance}%
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Rainfall chart */}
          <div className="card">
            <h3 style={styles.sectionTitle}>🌧️ Hourly Rainfall Projection</h3>
            <ResponsiveContainer width="100%" height={160}>
              <LineChart data={weather.hourly} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="hour" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} interval={3} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} unit="mm" />
                <Tooltip
                  contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-lit)', borderRadius: '8px' }}
                  labelStyle={{ color: 'var(--text-primary)' }}
                  itemStyle={{ color: '#06b6d4' }}
                />
                <Line type="monotone" dataKey="rain" stroke="#06b6d4" strokeWidth={2} dot={false} name="Rainfall mm" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </>
      )}
    </div>
  );
}

const styles = {
  adviceBanner: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem',
    padding: '0.85rem 1.25rem',
    background: 'rgba(34,197,94,0.07)',
    border: '1px solid rgba(34,197,94,0.2)',
    borderRadius: 'var(--radius-md)',
    marginBottom: '1.5rem',
    color: 'var(--text-primary)',
  },
  heroCard: {
    background: 'var(--bg-card)',
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-lg)',
    padding: '2rem',
    display: 'flex',
    gap: '2rem',
    marginBottom: '1.5rem',
    flexWrap: 'wrap',
    backgroundImage: 'radial-gradient(ellipse at top left, rgba(34,197,94,0.06) 0%, transparent 60%)',
  },
  heroLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '1.5rem',
    flex: '0 0 auto',
  },
  weatherIcon: { fontSize: '5rem', lineHeight: 1 },
  tempBig:    { fontSize: '3.5rem', fontWeight: 800, lineHeight: 1, fontFamily: 'var(--font-mono)' },
  feelsLike:  { fontSize: '0.9rem', color: 'var(--text-secondary)', marginTop: '0.25rem' },
  condition:  { fontSize: '1.1rem', fontWeight: 600, color: 'var(--green-bright)', marginTop: '0.25rem' },
  heroStats: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: '1rem 2rem',
    flex: 1,
    alignContent: 'center',
  },
  heroStat: { display: 'flex', alignItems: 'center', gap: '0.6rem' },
  heroStatIcon: { fontSize: '1.3rem' },
  sectionTitle: { fontSize: '1rem', fontWeight: 700, marginBottom: '1.25rem', color: 'var(--text-primary)' },
  forecastGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(7, 1fr)',
    gap: '0.75rem',
  },
  forecastDay: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    padding: '1rem 0.5rem',
    borderRadius: 'var(--radius-md)',
    border: '1px solid',
    transition: 'var(--transition)',
  },
  forecastDayName: { fontWeight: 700, fontSize: '0.8rem', color: 'var(--text-secondary)' },
  forecastCond: { fontSize: '0.7rem', color: 'var(--text-muted)', textAlign: 'center', marginBottom: '0.4rem' },
  forecastTemps: { display: 'flex', gap: '0.25rem', fontFamily: 'var(--font-mono)', fontSize: '0.9rem' },
  rainChance: { fontSize: '0.72rem', color: 'var(--cyan)', marginTop: '0.4rem', fontFamily: 'var(--font-mono)' },
};
