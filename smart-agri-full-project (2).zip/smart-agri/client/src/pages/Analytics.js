/**
 * Analytics.js - Farm analytics, crop performance, sensor trends
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { cropAPI, farmAPI, sensorAPI, alertAPI } from '../utils/api';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, RadarChart, Radar, PolarGrid, PolarAngleAxis,
} from 'recharts';

const COLORS = ['#22c55e', '#3b82f6', '#f59e0b', '#ef4444', '#ec4899', '#06b6d4', '#8b5cf6'];

export default function Analytics() {
  const { token } = useAuth();
  const [crops,   setCrops]   = useState([]);
  const [farms,   setFarms]   = useState([]);
  const [sensors, setSensors] = useState([]);
  const [alerts,  setAlerts]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [range,   setRange]   = useState('month'); // week | month | year

  const load = useCallback(async () => {
    setLoading(true);
    const [c, f, a] = await Promise.all([
      cropAPI.getAll(token),
      farmAPI.getAll(token),
      alertAPI.getAll(token),
    ]);
    if (c.success) setCrops(c.data);
    if (f.success) setFarms(f.data);
    if (a.success) setAlerts(a.data);

    // Load sensors from first farm
    if (f.success && f.data[0]) {
      const s = await sensorAPI.getAll(token, f.data[0]._id);
      if (s.success) setSensors(s.data);
    }
    setLoading(false);
  }, [token]);

  useEffect(() => { load(); }, [load]);

  // ── Derived data ──────────────────────────────────────────────

  // Crop status distribution (pie)
  const statusDist = ['planted', 'growing', 'flowering', 'harvested', 'failed'].map(s => ({
    name: s.charAt(0).toUpperCase() + s.slice(1),
    value: crops.filter(c => c.status === s).length,
  })).filter(d => d.value > 0);

  // Crops per farm (bar)
  const cropsPerFarm = farms.map(f => ({
    name: f.name.length > 14 ? f.name.slice(0, 14) + '…' : f.name,
    crops: crops.filter(c => (c.farm?._id || c.farm) === f._id).length,
    area: crops.filter(c => (c.farm?._id || c.farm) === f._id)
               .reduce((sum, c) => sum + (c.area?.value || 0), 0),
  }));

  // Health score distribution
  const healthBuckets = [
    { range: '0–25%',   count: crops.filter(c => c.healthScore <= 25).length, color: 'var(--red)' },
    { range: '26–50%',  count: crops.filter(c => c.healthScore > 25 && c.healthScore <= 50).length, color: 'var(--amber)' },
    { range: '51–75%',  count: crops.filter(c => c.healthScore > 50 && c.healthScore <= 75).length, color: '#84cc16' },
    { range: '76–100%', count: crops.filter(c => c.healthScore > 75).length, color: 'var(--green-mid)' },
  ];

  // Alert categories (pie)
  const alertCats = Object.entries(
    alerts.reduce((acc, a) => { acc[a.category] = (acc[a.category] || 0) + 1; return acc; }, {})
  ).map(([name, value]) => ({ name, value }));

  // Mock monthly yield trend
  const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const yieldTrend = months.slice(0, new Date().getMonth() + 1).map((m, i) => ({
    month: m,
    yield: Math.floor(800 + Math.sin(i) * 200 + Math.random() * 300),
    target: 1000,
  }));

  // Radar — farm performance metrics (mock scores)
  const radarData = [
    { metric: 'Soil Health',    score: 78 },
    { metric: 'Water Usage',    score: 65 },
    { metric: 'Crop Diversity', score: Math.min(crops.length * 15, 100) },
    { metric: 'Yield Rate',     score: 82 },
    { metric: 'Pest Control',   score: 70 },
    { metric: 'Sensor Coverage',score: Math.min(sensors.length * 20, 100) },
  ];

  // Sensor readings sparkline (mock trend from currentValue)
  const sensorTrend = sensors.slice(0, 4).map(s => ({
    name: s.name,
    data: Array.from({ length: 12 }, (_, i) => ({
      t: `${i * 2}h`,
      v: +(s.currentValue + (Math.random() - 0.5) * 10).toFixed(1),
    })),
    unit: s.unit,
    color: COLORS[sensors.indexOf(s) % COLORS.length],
  }));

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border-lit)', borderRadius: '8px', padding: '0.75rem 1rem', fontSize: '0.8rem' }}>
        <div style={{ fontWeight: 700, marginBottom: '0.4rem', color: 'var(--text-primary)' }}>{label}</div>
        {payload.map((p, i) => (
          <div key={i} style={{ color: p.color }}>{p.name}: {p.value}{p.unit || ''}</div>
        ))}
      </div>
    );
  };

  if (loading) return (
    <div className="flex-center" style={{ minHeight: '60vh' }}>
      <div style={{ fontSize: '3rem', animation: 'spin 1s linear infinite' }}>📊</div>
    </div>
  );

  const avgHealth = crops.length > 0
    ? (crops.reduce((s, c) => s + (c.healthScore || 0), 0) / crops.length).toFixed(1)
    : 0;

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">📊 Farm Analytics</h1>
          <p className="page-subtitle">Data-driven insights for {farms.length} farm{farms.length !== 1 ? 's' : ''}</p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          {['week', 'month', 'year'].map(r => (
            <button key={r} className={`btn ${range === r ? 'btn-primary' : 'btn-ghost'} btn-sm`}
              onClick={() => setRange(r)}>
              {r.charAt(0).toUpperCase() + r.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* KPI summary row */}
      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        <div className="stat-card">
          <span className="stat-icon">🌾</span>
          <div className="stat-label">Total Crops</div>
          <div className="stat-value text-green">{crops.length}</div>
          <div className="stat-sub">across {farms.length} farms</div>
        </div>
        <div className="stat-card">
          <span className="stat-icon">💪</span>
          <div className="stat-label">Avg Health</div>
          <div className="stat-value" style={{ color: avgHealth >= 70 ? 'var(--green-bright)' : 'var(--amber)' }}>{avgHealth}%</div>
          <div className="stat-sub">crop health score</div>
        </div>
        <div className="stat-card">
          <span className="stat-icon">🔔</span>
          <div className="stat-label">Total Alerts</div>
          <div className="stat-value text-amber">{alerts.length}</div>
          <div className="stat-sub">{alerts.filter(a => a.type === 'critical').length} critical</div>
        </div>
        <div className="stat-card">
          <span className="stat-icon">📡</span>
          <div className="stat-label">Sensors</div>
          <div className="stat-value" style={{ color: 'var(--cyan)' }}>{sensors.length}</div>
          <div className="stat-sub">{sensors.filter(s => s.isActive).length} active</div>
        </div>
      </div>

      {/* Row 1: Yield trend + Crop status pie */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '1.5rem', marginBottom: '1.5rem' }}>
        {/* Yield trend */}
        <div className="card">
          <h3 style={styles.sectionTitle}>📈 Monthly Yield Trend (kg)</h3>
          <ResponsiveContainer width="100%" height={240}>
            <AreaChart data={yieldTrend}>
              <defs>
                <linearGradient id="yieldGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#22c55e" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
              <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: '12px', color: 'var(--text-secondary)' }} />
              <Area type="monotone" dataKey="yield"  stroke="#22c55e" fill="url(#yieldGrad)" strokeWidth={2} name="Actual (kg)" />
              <Line  type="monotone" dataKey="target" stroke="#f59e0b" strokeWidth={2} strokeDasharray="5 5" dot={false} name="Target (kg)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Crop status pie */}
        <div className="card">
          <h3 style={styles.sectionTitle}>🥧 Crop Status Distribution</h3>
          {statusDist.length === 0 ? (
            <div className="flex-center" style={{ height: '200px', color: 'var(--text-muted)' }}>No crop data</div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={statusDist} cx="50%" cy="50%" innerRadius={55} outerRadius={85}
                    paddingAngle={3} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    labelLine={false}>
                    {statusDist.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-lit)', borderRadius: '8px', fontSize: '0.8rem' }} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', justifyContent: 'center', marginTop: '0.5rem' }}>
                {statusDist.map((d, i) => (
                  <span key={d.name} style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
                    <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: COLORS[i % COLORS.length], display: 'inline-block' }} />
                    {d.name}
                  </span>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Row 2: Bar charts */}
      <div className="grid-2" style={{ marginBottom: '1.5rem' }}>
        {/* Crops per farm */}
        <div className="card">
          <h3 style={styles.sectionTitle}>🏡 Crops & Area per Farm</h3>
          {cropsPerFarm.length === 0 ? (
            <div className="flex-center" style={{ height: '200px', color: 'var(--text-muted)' }}>No farm data</div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={cropsPerFarm}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" tick={{ fill: 'var(--text-muted)', fontSize: 10 }} />
                <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend wrapperStyle={{ fontSize: '12px', color: 'var(--text-secondary)' }} />
                <Bar dataKey="crops" fill="#22c55e" name="Crops" radius={[4, 4, 0, 0]} />
                <Bar dataKey="area"  fill="#3b82f6" name="Area (acres)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Health distribution */}
        <div className="card">
          <h3 style={styles.sectionTitle}>💪 Crop Health Distribution</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={healthBuckets}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="range" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
              <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} allowDecimals={false} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="count" name="Crops" radius={[4, 4, 0, 0]}>
                {healthBuckets.map((b, i) => <Cell key={i} fill={b.color} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Row 3: Radar + Alert breakdown */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', marginBottom: '1.5rem' }}>
        {/* Radar chart */}
        <div className="card">
          <h3 style={styles.sectionTitle}>🕸️ Farm Performance Radar</h3>
          <ResponsiveContainer width="100%" height={260}>
            <RadarChart data={radarData}>
              <PolarGrid stroke="var(--border)" />
              <PolarAngleAxis dataKey="metric" tick={{ fill: 'var(--text-secondary)', fontSize: 11 }} />
              <Radar name="Score" dataKey="score" stroke="#22c55e" fill="#22c55e" fillOpacity={0.2} strokeWidth={2} />
              <Tooltip contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-lit)', borderRadius: '8px', fontSize: '0.8rem' }} />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Alert category pie */}
        <div className="card">
          <h3 style={styles.sectionTitle}>🔔 Alerts by Category</h3>
          {alertCats.length === 0 ? (
            <div className="flex-center" style={{ height: '240px', color: 'var(--text-muted)' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🎉</div>
                <div>No alerts recorded</div>
              </div>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={alertCats} cx="50%" cy="50%" outerRadius={100} dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}>
                  {alertCats.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-lit)', borderRadius: '8px', fontSize: '0.8rem' }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Sensor trends */}
      {sensorTrend.length > 0 && (
        <div className="card">
          <h3 style={styles.sectionTitle}>📡 Sensor Readings — 24h Trend</h3>
          <div className="grid-2">
            {sensorTrend.map(s => (
              <div key={s.name}>
                <div style={{ fontSize: '0.8rem', fontWeight: 600, color: s.color, marginBottom: '0.5rem' }}>
                  {s.name} ({s.unit})
                </div>
                <ResponsiveContainer width="100%" height={100}>
                  <LineChart data={s.data}>
                    <XAxis dataKey="t" tick={{ fill: 'var(--text-muted)', fontSize: 9 }} interval={3} />
                    <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 9 }} width={30} />
                    <Tooltip contentStyle={{ background: 'var(--bg-card)', border: '1px solid var(--border-lit)', borderRadius: '6px', fontSize: '0.75rem' }} />
                    <Line type="monotone" dataKey="v" stroke={s.color} strokeWidth={1.5} dot={false} name={s.unit} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  sectionTitle: { fontSize: '1rem', fontWeight: 700, marginBottom: '1.25rem', color: 'var(--text-primary)' },
};
