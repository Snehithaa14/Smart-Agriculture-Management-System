/**
 * FarmView.js - Detailed view for a single farm: crops, sensors, alerts
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { farmAPI, cropAPI, sensorAPI, alertAPI } from '../utils/api';
import { playClick, playSuccess, playError } from '../utils/sounds';
import SensorGauge from '../components/common/SensorGauge';
import FarmScene3D from '../components/3d/FarmScene3D';

const SENSOR_TYPES = ['temperature', 'humidity', 'soil', 'light', 'rainfall', 'wind'];

export default function FarmView() {
  const { id } = useParams();
  const { token } = useAuth();

  const [farm,    setFarm]    = useState(null);
  const [crops,   setCrops]   = useState([]);
  const [sensors, setSensors] = useState([]);
  const [alerts,  setAlerts]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab,     setTab]     = useState('overview'); // overview | sensors | alerts

  // Sensor modal
  const [sensorModal, setSensorModal] = useState(false);
  const [sensorForm,  setSensorForm]  = useState({ name: '', type: 'temperature', location: '', thresholds: { min: '', max: '' } });
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [fRes, cRes, sRes, aRes] = await Promise.all([
        farmAPI.getOne(token, id),
        cropAPI.getAll(token, id),
        sensorAPI.getAll(token, id),
        alertAPI.getAll(token),
      ]);
      if (fRes.success) setFarm(fRes.data);
      if (cRes.success) setCrops(cRes.data);
      if (sRes.success) setSensors(sRes.data);
      if (aRes.success) setAlerts(aRes.data.filter(a => a.farm === id || a.farm?._id === id));
    } finally {
      setLoading(false);
    }
  }, [token, id]);

  useEffect(() => { load(); }, [load]);

  const handleAddSensor = async (e) => {
    e.preventDefault();
    playClick();
    setSaving(true);
    try {
      const payload = {
        ...sensorForm,
        farm: id,
        thresholds: {
          min: Number(sensorForm.thresholds.min) || undefined,
          max: Number(sensorForm.thresholds.max) || undefined,
        },
      };
      const res = await sensorAPI.create(token, payload);
      if (res.success) {
        playSuccess();
        setSensors(p => [...p, res.data]);
        setSensorModal(false);
        setSensorForm({ name: '', type: 'temperature', location: '', thresholds: { min: '', max: '' } });
      } else {
        playError();
      }
    } catch { playError(); }
    finally { setSaving(false); }
  };

  const handleDeleteSensor = async (sid) => {
    if (!window.confirm('Delete this sensor?')) return;
    playClick();
    const res = await sensorAPI.delete(token, sid);
    if (res.success) {
      playSuccess();
      setSensors(p => p.filter(s => s._id !== sid));
    }
  };

  const handleMarkAlertRead = async (aid) => {
    await alertAPI.markRead(token, aid);
    setAlerts(p => p.map(a => a._id === aid ? { ...a, isRead: true } : a));
  };

  const sensorIcon = { temperature: '🌡️', humidity: '💧', soil: '🌍', light: '☀️', rainfall: '🌧️', wind: '💨' };
  const sensorColor = { temperature: '#f59e0b', humidity: '#06b6d4', soil: '#22c55e', light: '#fde68a', rainfall: '#3b82f6', wind: '#8b5cf6' };

  if (loading) return (
    <div className="flex-center" style={{ minHeight: '60vh' }}>
      <div style={{ fontSize: '3rem', animation: 'spin 1s linear infinite' }}>🏡</div>
    </div>
  );

  if (!farm) return (
    <div style={{ textAlign: 'center', padding: '4rem' }}>
      <div style={{ fontSize: '3rem' }}>❌</div>
      <p style={{ color: 'var(--text-muted)', marginTop: '1rem' }}>Farm not found</p>
      <Link to="/" className="btn btn-outline" style={{ marginTop: '1rem' }}>← Back to Dashboard</Link>
    </div>
  );

  return (
    <div>
      {/* Breadcrumb */}
      <div style={styles.breadcrumb}>
        <Link to="/" style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>Dashboard</Link>
        <span style={{ color: 'var(--text-muted)' }}> / </span>
        <span style={{ color: 'var(--text-primary)', fontSize: '0.85rem' }}>{farm.name}</span>
      </div>

      {/* Farm header */}
      <div style={styles.farmHeader}>
        <div>
          <h1 className="page-title">🏡 {farm.name}</h1>
          <p style={{ color: 'var(--text-secondary)', fontSize: '0.875rem', marginTop: '0.25rem' }}>
            📍 {farm.location?.address} · {farm.size?.value} {farm.size?.unit} · {farm.soilType} soil · {farm.irrigationType} irrigation
          </p>
        </div>
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <Link to="/crops" className="btn btn-outline btn-sm">🌾 Manage Crops</Link>
          <button className="btn btn-primary btn-sm" onClick={() => { playClick(); setSensorModal(true); }}>+ Add Sensor</button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        {[
          { label: 'Total Crops',   value: crops.length,                                   icon: '🌾', color: 'var(--green-bright)' },
          { label: 'Active Sensors',value: sensors.filter(s => s.isActive).length,          icon: '📡', color: 'var(--cyan)' },
          { label: 'Alerts',        value: alerts.filter(a => !a.isRead).length,            icon: '🔔', color: 'var(--amber)' },
          { label: 'Avg Health',    value: crops.length ? Math.round(crops.reduce((s,c) => s + (c.healthScore||0), 0) / crops.length) + '%' : 'N/A', icon: '💪', color: 'var(--green-mid)' },
        ].map(s => (
          <div key={s.label} className="stat-card">
            <span className="stat-icon">{s.icon}</span>
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={styles.tabs}>
        {['overview', 'sensors', 'alerts'].map(t => (
          <button key={t} className={`btn ${tab === t ? 'btn-primary' : 'btn-ghost'}`}
            onClick={() => { playClick(); setTab(t); }}>
            {t === 'overview' ? '⬡ Overview' : t === 'sensors' ? '📡 Sensors' : '🔔 Alerts'}
          </button>
        ))}
      </div>

      {/* ── Overview tab ── */}
      {tab === 'overview' && (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 340px', gap: '1.5rem' }}>
          <div className="card" style={{ padding: '1rem' }}>
            <h3 style={styles.sectionTitle}>🌍 3D Farm Visualization</h3>
            <FarmScene3D crops={crops} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {/* Farm details */}
            <div className="card">
              <h3 style={styles.sectionTitle}>📋 Farm Details</h3>
              {[
                ['Owner', farm.owner?.name || '—'],
                ['Soil Type', farm.soilType],
                ['Irrigation', farm.irrigationType],
                ['Farm Size', `${farm.size?.value} ${farm.size?.unit}`],
                ['Total Crops', crops.length],
                ['Created', new Date(farm.createdAt).toLocaleDateString()],
              ].map(([k, v]) => (
                <div key={k} style={styles.detailRow}>
                  <span style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>{k}</span>
                  <span style={{ fontWeight: 600, fontSize: '0.875rem', fontFamily: 'var(--font-mono)' }}>{v}</span>
                </div>
              ))}
            </div>
            {/* Sensor mini gauges */}
            {sensors.length > 0 && (
              <div className="card">
                <h3 style={styles.sectionTitle}>📡 Live Readings</h3>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'center' }}>
                  {sensors.slice(0, 4).map(s => (
                    <SensorGauge key={s._id}
                      value={s.currentValue}
                      unit={s.unit}
                      label={s.name}
                      max={s.type === 'temperature' ? 50 : 100}
                      color={sensorColor[s.type]}
                      size={100}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ── Sensors tab ── */}
      {tab === 'sensors' && (
        <div>
          {sensors.length === 0 ? (
            <div style={styles.empty}>
              <div style={{ fontSize: '3rem' }}>📡</div>
              <p>No sensors added yet</p>
              <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={() => { playClick(); setSensorModal(true); }}>
                + Add First Sensor
              </button>
            </div>
          ) : (
            <div className="grid-3">
              {sensors.map(s => (
                <div key={s._id} className="card">
                  <div style={styles.sensorTop}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                      <span style={{ fontSize: '1.5rem' }}>{sensorIcon[s.type]}</span>
                      <div>
                        <div style={{ fontWeight: 700 }}>{s.name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'capitalize' }}>{s.type}</div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: '0.4rem', alignItems: 'center' }}>
                      <span className={`badge ${s.isActive ? 'badge-green' : 'badge-red'}`}>{s.isActive ? 'Active' : 'Offline'}</span>
                      <button className="btn btn-ghost btn-sm" style={{ padding: '0.25rem' }} onClick={() => handleDeleteSensor(s._id)}>🗑️</button>
                    </div>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'center', margin: '0.75rem 0' }}>
                    <SensorGauge
                      value={s.currentValue}
                      unit={s.unit}
                      label={s.type}
                      max={s.type === 'temperature' ? 50 : 100}
                      color={sensorColor[s.type]}
                      size={110}
                    />
                  </div>

                  <div style={styles.sensorMeta}>
                    <div>📍 {s.location || 'Main Field'}</div>
                    <div>🔋 {s.batteryLevel}%</div>
                    {s.thresholds?.min && <div style={{ color: 'var(--blue)' }}>Min: {s.thresholds.min}{s.unit}</div>}
                    {s.thresholds?.max && <div style={{ color: 'var(--red)' }}>Max: {s.thresholds.max}{s.unit}</div>}
                  </div>

                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.5rem', fontFamily: 'var(--font-mono)' }}>
                    Last ping: {new Date(s.lastPing).toLocaleTimeString()}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Alerts tab ── */}
      {tab === 'alerts' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {alerts.length === 0 ? (
            <div style={styles.empty}>
              <div style={{ fontSize: '3rem' }}>🎉</div>
              <p>No alerts for this farm — all clear!</p>
            </div>
          ) : (
            alerts.map(alert => (
              <div key={alert._id} className={`alert-item ${alert.type} ${!alert.isRead ? 'unread' : ''}`}
                style={{ cursor: alert.isRead ? 'default' : 'pointer' }}
                onClick={() => !alert.isRead && handleMarkAlertRead(alert._id)}>
                <span style={{ fontSize: '1.2rem' }}>
                  {{ critical: '🔴', warning: '🟡', info: '🔵', success: '🟢' }[alert.type] || '⚪'}
                </span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 700, fontSize: '0.9rem' }}>{alert.title}</div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', marginTop: '0.2rem' }}>{alert.message}</div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginTop: '0.25rem', fontFamily: 'var(--font-mono)' }}>
                    {new Date(alert.createdAt).toLocaleString()} · {alert.category} · {alert.priority}
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.3rem', alignItems: 'flex-end' }}>
                  {!alert.isRead && <span className="badge badge-green" style={{ fontSize: '0.65rem' }}>NEW</span>}
                  {alert.isResolved && <span className="badge badge-cyan" style={{ fontSize: '0.65rem' }}>RESOLVED</span>}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Add Sensor Modal */}
      {sensorModal && (
        <div className="modal-overlay" onClick={() => setSensorModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <h2 className="modal-title">📡 Add New Sensor</h2>
            <form onSubmit={handleAddSensor}>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Sensor Name *</label>
                  <input className="form-input" placeholder="e.g. North Field Temp" required
                    value={sensorForm.name}
                    onChange={e => setSensorForm(p => ({ ...p, name: e.target.value }))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Type *</label>
                  <select className="form-select"
                    value={sensorForm.type}
                    onChange={e => setSensorForm(p => ({ ...p, type: e.target.value }))}>
                    {SENSOR_TYPES.map(t => (
                      <option key={t} value={t}>{sensorIcon[t]} {t.charAt(0).toUpperCase() + t.slice(1)}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Location / Zone</label>
                <input className="form-input" placeholder="e.g. North Field, Greenhouse A"
                  value={sensorForm.location}
                  onChange={e => setSensorForm(p => ({ ...p, location: e.target.value }))} />
              </div>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Min Threshold</label>
                  <input type="number" className="form-input" placeholder="e.g. 10"
                    value={sensorForm.thresholds.min}
                    onChange={e => setSensorForm(p => ({ ...p, thresholds: { ...p.thresholds, min: e.target.value } }))} />
                </div>
                <div className="form-group">
                  <label className="form-label">Max Threshold</label>
                  <input type="number" className="form-input" placeholder="e.g. 40"
                    value={sensorForm.thresholds.max}
                    onChange={e => setSensorForm(p => ({ ...p, thresholds: { ...p.thresholds, max: e.target.value } }))} />
                </div>
              </div>
              <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
                <button type="button" className="btn btn-ghost" onClick={() => { playClick(); setSensorModal(false); }}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>
                  {saving ? <><span className="spinner" /> Adding...</> : '+ Add Sensor'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  breadcrumb: { marginBottom: '1rem', display: 'flex', alignItems: 'center', gap: '0.25rem' },
  farmHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem', flexWrap: 'wrap', gap: '1rem' },
  tabs: { display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' },
  sectionTitle: { fontSize: '0.95rem', fontWeight: 700, marginBottom: '1rem', color: 'var(--text-primary)' },
  detailRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '0.5rem 0', borderBottom: '1px solid var(--border)' },
  sensorTop: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' },
  sensorMeta: { display: 'flex', flexWrap: 'wrap', gap: '0.5rem', fontSize: '0.75rem', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' },
  empty: { textAlign: 'center', padding: '4rem 2rem', color: 'var(--text-secondary)' },
};
