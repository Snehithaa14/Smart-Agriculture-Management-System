/**
 * CropManagement.js - Full CRUD interface for crop management
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import { cropAPI, farmAPI } from '../utils/api';
import { playClick, playSuccess, playError } from '../utils/sounds';

const STATUSES = ['planted', 'growing', 'flowering', 'harvested', 'failed'];

const CROP_SUGGESTIONS = [
  'Wheat', 'Rice', 'Maize', 'Cotton', 'Sugarcane',
  'Tomato', 'Potato', 'Onion', 'Soybean', 'Groundnut',
  'Sunflower', 'Barley', 'Chickpea', 'Mango', 'Banana',
];

export default function CropManagement() {
  const { token } = useAuth();
  const [crops, setCrops]     = useState([]);
  const [farms, setFarms]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter]   = useState({ farm: '', status: '' });
  const [search, setSearch]   = useState('');

  // Modal state
  const [modal, setModal]     = useState({ open: false, mode: 'create', crop: null });
  const [form, setForm]       = useState(emptyForm());
  const [errors, setErrors]   = useState({});
  const [saving, setSaving]   = useState(false);

  function emptyForm() {
    return {
      name: '', variety: '', farm: '', status: 'planted',
      plantedDate: new Date().toISOString().split('T')[0],
      harvestDate: '',
      area: { value: '', unit: 'acres' },
      expectedYield: { value: '', unit: 'kg' },
      waterRequirement: '',
      healthScore: 80,
      notes: '',
    };
  }

  const load = useCallback(async () => {
    setLoading(true);
    const [cRes, fRes] = await Promise.all([cropAPI.getAll(token), farmAPI.getAll(token)]);
    if (cRes.success) setCrops(cRes.data);
    if (fRes.success) setFarms(fRes.data);
    setLoading(false);
  }, [token]);

  useEffect(() => { load(); }, [load]);

  const openCreate = () => {
    playClick();
    setForm({ ...emptyForm(), farm: farms[0]?._id || '' });
    setErrors({});
    setModal({ open: true, mode: 'create', crop: null });
  };

  const openEdit = (crop) => {
    playClick();
    setForm({
      name: crop.name, variety: crop.variety || '', farm: crop.farm?._id || crop.farm,
      status: crop.status,
      plantedDate: crop.plantedDate ? crop.plantedDate.split('T')[0] : '',
      harvestDate: crop.harvestDate  ? crop.harvestDate.split('T')[0]  : '',
      area: crop.area || { value: '', unit: 'acres' },
      expectedYield: crop.expectedYield || { value: '', unit: 'kg' },
      waterRequirement: crop.waterRequirement || '',
      healthScore: crop.healthScore || 80,
      notes: crop.notes || '',
    });
    setErrors({});
    setModal({ open: true, mode: 'edit', crop });
  };

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = 'Crop name required';
    if (!form.farm)        errs.farm = 'Select a farm';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSave = async (e) => {
    e.preventDefault();
    playClick();
    if (!validate()) { playError(); return; }
    setSaving(true);
    try {
      const payload = {
        ...form,
        area: { ...form.area, value: Number(form.area.value) },
        expectedYield: { ...form.expectedYield, value: Number(form.expectedYield.value) },
        waterRequirement: Number(form.waterRequirement),
        healthScore: Number(form.healthScore),
      };
      let res;
      if (modal.mode === 'create') {
        res = await cropAPI.create(token, payload);
        if (res.success) { setCrops(p => [res.data, ...p]); }
      } else {
        res = await cropAPI.update(token, modal.crop._id, payload);
        if (res.success) { setCrops(p => p.map(c => c._id === modal.crop._id ? res.data : c)); }
      }
      if (res.success) {
        playSuccess();
        setModal({ open: false });
      } else {
        playError();
        setErrors({ api: res.message });
      }
    } catch { playError(); }
    finally { setSaving(false); }
  };

  const handleDelete = async (crop) => {
    if (!window.confirm(`Delete "${crop.name}"? This cannot be undone.`)) return;
    playClick();
    const res = await cropAPI.delete(token, crop._id);
    if (res.success) {
      playSuccess();
      setCrops(p => p.filter(c => c._id !== crop._id));
    } else {
      playError();
    }
  };

  // Filtered crops
  const filtered = crops.filter(c => {
    const matchFarm   = !filter.farm   || (c.farm?._id || c.farm) === filter.farm;
    const matchStatus = !filter.status || c.status === filter.status;
    const matchSearch = !search || c.name.toLowerCase().includes(search.toLowerCase());
    return matchFarm && matchStatus && matchSearch;
  });

  const set = (field) => (e) => setForm(p => ({ ...p, [field]: e.target.value }));
  const setNested = (outer, field) => (e) =>
    setForm(p => ({ ...p, [outer]: { ...p[outer], [field]: e.target.value } }));

  const statusColor = { planted: '#3b82f6', growing: '#22c55e', flowering: '#ec4899', harvested: '#f59e0b', failed: '#ef4444' };

  return (
    <div>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">🌾 Crop Management</h1>
          <p className="page-subtitle">{crops.length} total crops across {farms.length} farms</p>
        </div>
        <button className="btn btn-primary" onClick={openCreate}>+ Add Crop</button>
      </div>

      {/* Filters */}
      <div style={styles.filters}>
        <input
          className="form-input"
          placeholder="🔍 Search crops..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ maxWidth: '220px' }}
        />
        <select className="form-select" style={{ maxWidth: '180px' }}
          value={filter.farm} onChange={e => setFilter(p => ({ ...p, farm: e.target.value }))}>
          <option value="">All Farms</option>
          {farms.map(f => <option key={f._id} value={f._id}>{f.name}</option>)}
        </select>
        <select className="form-select" style={{ maxWidth: '160px' }}
          value={filter.status} onChange={e => setFilter(p => ({ ...p, status: e.target.value }))}>
          <option value="">All Status</option>
          {STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
        </select>
        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem', marginLeft: 'auto' }}>
          {filtered.length} result{filtered.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Crop cards grid */}
      {loading ? (
        <div className="flex-center" style={{ height: '300px' }}>
          <div className="spinner" style={{ width: '36px', height: '36px' }} />
        </div>
      ) : filtered.length === 0 ? (
        <div style={styles.empty}>
          <div style={{ fontSize: '3rem' }}>🌱</div>
          <p>No crops found. Try adding one!</p>
        </div>
      ) : (
        <div className="grid-3">
          {filtered.map(crop => (
            <div key={crop._id} className="card" style={{ cursor: 'default' }}>
              {/* Status bar */}
              <div style={{ height: '4px', background: statusColor[crop.status] || '#22c55e', borderRadius: '4px 4px 0 0', margin: '-1.5rem -1.5rem 1rem', borderTop: 'none' }} />

              <div className="flex-between" style={{ marginBottom: '0.75rem' }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '1.05rem' }}>{crop.name}</div>
                  {crop.variety && <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>{crop.variety}</div>}
                </div>
                <span className={`badge badge-${statusBadge(crop.status)}`}>{crop.status}</span>
              </div>

              <div style={styles.cropMeta}>
                <div style={styles.metaItem}>
                  <span style={styles.metaLabel}>Farm</span>
                  <span style={styles.metaVal}>{crop.farm?.name || '—'}</span>
                </div>
                <div style={styles.metaItem}>
                  <span style={styles.metaLabel}>Area</span>
                  <span style={styles.metaVal}>{crop.area?.value ? `${crop.area.value} acres` : '—'}</span>
                </div>
                <div style={styles.metaItem}>
                  <span style={styles.metaLabel}>Planted</span>
                  <span style={styles.metaVal}>{crop.plantedDate ? new Date(crop.plantedDate).toLocaleDateString() : '—'}</span>
                </div>
                <div style={styles.metaItem}>
                  <span style={styles.metaLabel}>Health</span>
                  <span style={{ ...styles.metaVal, color: crop.healthScore >= 70 ? 'var(--green-mid)' : 'var(--amber)' }}>
                    {crop.healthScore}%
                  </span>
                </div>
              </div>

              {/* Health bar */}
              <div style={styles.healthBar}>
                <div style={{ ...styles.healthFill, width: `${crop.healthScore}%`, background: crop.healthScore >= 70 ? 'var(--green-mid)' : crop.healthScore >= 40 ? 'var(--amber)' : 'var(--red)' }} />
              </div>

              {crop.notes && (
                <p style={{ fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '0.75rem', fontStyle: 'italic' }}>
                  {crop.notes.substring(0, 80)}{crop.notes.length > 80 ? '…' : ''}
                </p>
              )}

              <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
                <button className="btn btn-outline btn-sm" style={{ flex: 1 }} onClick={() => openEdit(crop)}>✏️ Edit</button>
                <button className="btn btn-danger btn-sm"  onClick={() => handleDelete(crop)}>🗑️</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Modal */}
      {modal.open && (
        <div className="modal-overlay" onClick={() => setModal({ open: false })}>
          <div className="modal" onClick={e => e.stopPropagation()} style={{ maxWidth: '620px' }}>
            <h2 className="modal-title">{modal.mode === 'create' ? '🌱 Add New Crop' : '✏️ Edit Crop'}</h2>

            {errors.api && <div style={styles.apiErr}>{errors.api}</div>}

            <form onSubmit={handleSave} noValidate>
              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Crop Name *</label>
                  <input list="crop-list" className={`form-input${errors.name ? ' error' : ''}`}
                    placeholder="e.g. Wheat" value={form.name} onChange={set('name')} />
                  <datalist id="crop-list">
                    {CROP_SUGGESTIONS.map(c => <option key={c} value={c} />)}
                  </datalist>
                  {errors.name && <span className="form-error">{errors.name}</span>}
                </div>
                <div className="form-group">
                  <label className="form-label">Variety</label>
                  <input className="form-input" placeholder="e.g. HD-2967" value={form.variety} onChange={set('variety')} />
                </div>
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Farm *</label>
                  <select className={`form-select${errors.farm ? ' error' : ''}`} value={form.farm} onChange={set('farm')}>
                    <option value="">Select farm...</option>
                    {farms.map(f => <option key={f._id} value={f._id}>{f.name}</option>)}
                  </select>
                  {errors.farm && <span className="form-error">{errors.farm}</span>}
                </div>
                <div className="form-group">
                  <label className="form-label">Status</label>
                  <select className="form-select" value={form.status} onChange={set('status')}>
                    {STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Planted Date</label>
                  <input type="date" className="form-input" value={form.plantedDate} onChange={set('plantedDate')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Expected Harvest</label>
                  <input type="date" className="form-input" value={form.harvestDate} onChange={set('harvestDate')} />
                </div>
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Area (acres)</label>
                  <input type="number" className="form-input" placeholder="5" value={form.area.value} onChange={setNested('area', 'value')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Expected Yield (kg)</label>
                  <input type="number" className="form-input" placeholder="2000" value={form.expectedYield.value} onChange={setNested('expectedYield', 'value')} />
                </div>
              </div>

              <div className="grid-2">
                <div className="form-group">
                  <label className="form-label">Water Req. (L/day/acre)</label>
                  <input type="number" className="form-input" placeholder="500" value={form.waterRequirement} onChange={set('waterRequirement')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Health Score: {form.healthScore}%</label>
                  <input type="range" min="0" max="100" value={form.healthScore} onChange={set('healthScore')}
                    style={{ width: '100%', accentColor: 'var(--green-mid)', marginTop: '0.5rem' }} />
                </div>
              </div>

              <div className="form-group">
                <label className="form-label">Notes</label>
                <textarea className="form-textarea" placeholder="Any additional notes about this crop..." value={form.notes} onChange={set('notes')} />
              </div>

              <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'flex-end' }}>
                <button type="button" className="btn btn-ghost" onClick={() => { playClick(); setModal({ open: false }); }}>Cancel</button>
                <button type="submit" className="btn btn-primary" disabled={saving}>
                  {saving ? <><span className="spinner" /> Saving...</> : modal.mode === 'create' ? '+ Add Crop' : '✓ Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

const statusBadge = (s) => ({ planted: 'blue', growing: 'green', flowering: 'cyan', harvested: 'amber', failed: 'red' }[s] || 'blue');

const styles = {
  filters: { display: 'flex', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center' },
  empty:   { textAlign: 'center', padding: '4rem', color: 'var(--text-secondary)', fontSize: '1rem' },
  cropMeta: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '0.75rem' },
  metaItem:  { display: 'flex', flexDirection: 'column', gap: '0.1rem' },
  metaLabel: { fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', fontWeight: 600 },
  metaVal:   { fontSize: '0.875rem', color: 'var(--text-primary)', fontFamily: 'var(--font-mono)' },
  healthBar: { height: '4px', background: 'var(--border)', borderRadius: '2px', overflow: 'hidden' },
  healthFill: { height: '100%', borderRadius: '2px', transition: 'width 0.5s ease' },
  apiErr: { background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 'var(--radius-sm)', padding: '0.75rem', color: 'var(--red)', fontSize: '0.875rem', marginBottom: '1rem' },
};
