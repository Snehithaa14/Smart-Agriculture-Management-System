const express = require('express');
const router  = express.Router();
const { registerUser, loginUser, getMe, updateProfile, getAllUsers } = require('../controllers/userController');
const { protect, authorize } = require('../middleware/auth');

router.post('/register', registerUser);
router.post('/login',    loginUser);
router.get('/me',        protect, getMe);
router.put('/me',        protect, updateProfile);
router.get('/',          protect, authorize('admin'), getAllUsers);

module.exports = router;
