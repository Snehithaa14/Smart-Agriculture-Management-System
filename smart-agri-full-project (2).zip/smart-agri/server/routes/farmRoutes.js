const express = require('express');
const router  = express.Router();
const { getFarms, getFarm, createFarm, updateFarm, deleteFarm } = require('../controllers/farmController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.route('/').get(getFarms).post(createFarm);
router.route('/:id').get(getFarm).put(updateFarm).delete(deleteFarm);

module.exports = router;
