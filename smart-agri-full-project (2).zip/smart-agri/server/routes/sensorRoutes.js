const express = require('express');
const router  = express.Router();
const { getSensors, getSensor, createSensor, addReading, updateSensor, deleteSensor } = require('../controllers/sensorController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.route('/').get(getSensors).post(createSensor);
router.route('/:id').get(getSensor).put(updateSensor).delete(deleteSensor);
router.post('/:id/readings', addReading);

module.exports = router;
