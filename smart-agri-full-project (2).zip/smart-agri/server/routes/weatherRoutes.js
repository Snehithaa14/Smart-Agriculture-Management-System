const express = require('express');
const router  = express.Router();
const { getWeather, getWeatherAlerts } = require('../controllers/weatherController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.get('/', getWeather);
router.get('/alerts', getWeatherAlerts);

module.exports = router;
