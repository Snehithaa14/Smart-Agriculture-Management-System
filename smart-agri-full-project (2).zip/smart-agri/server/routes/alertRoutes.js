const express = require('express');
const router  = express.Router();
const { getAlerts, createAlert, markRead, markAllRead, resolveAlert, deleteAlert } = require('../controllers/alertController');
const { protect } = require('../middleware/auth');

router.use(protect);
router.route('/').get(getAlerts).post(createAlert);
router.put('/read-all', markAllRead);
router.route('/:id').delete(deleteAlert);
router.put('/:id/read',    markRead);
router.put('/:id/resolve', resolveAlert);

module.exports = router;
