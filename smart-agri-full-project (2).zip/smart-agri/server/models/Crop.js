/**
 * Crop Model
 * Tracks crop lifecycle, health, and harvest data
 */

const mongoose = require('mongoose');

const CropSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Crop name is required'],
      trim: true,
    },
    variety: { type: String },
    farm: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farm',
      required: true,
    },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    status: {
      type: String,
      enum: ['planted', 'growing', 'flowering', 'harvested', 'failed'],
      default: 'planted',
    },
    plantedDate:  { type: Date, default: Date.now },
    harvestDate:  { type: Date },
    area: {
      value: { type: Number },   // in acres
      unit:  { type: String, default: 'acres' },
    },
    expectedYield: {
      value: { type: Number },
      unit:  { type: String, default: 'kg' },
    },
    actualYield: {
      value: { type: Number },
      unit:  { type: String, default: 'kg' },
    },
    waterRequirement: { type: Number },   // litres per day per acre
    fertilizer: {
      type:     { type: String },
      schedule: { type: String },
      lastApplied: { type: Date },
    },
    healthScore: { type: Number, min: 0, max: 100, default: 80 },
    notes: { type: String, maxlength: 1000 },
    imageUrl: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Crop', CropSchema);
