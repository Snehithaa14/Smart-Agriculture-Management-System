/**
 * Farm Model
 * Represents a farm with location, size, and owner reference
 */

const mongoose = require('mongoose');

const FarmSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Farm name is required'],
      trim: true,
    },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    location: {
      address: { type: String, required: true },
      city:    { type: String },
      state:   { type: String },
      country: { type: String, default: 'India' },
      coordinates: {
        lat: { type: Number },
        lng: { type: Number },
      },
    },
    size: {
      value: { type: Number, required: true },    // in acres
      unit:  { type: String, default: 'acres' },
    },
    soilType: {
      type: String,
      enum: ['clay', 'sandy', 'loamy', 'silty', 'peaty', 'chalky', 'mixed'],
      default: 'loamy',
    },
    irrigationType: {
      type: String,
      enum: ['drip', 'sprinkler', 'flood', 'manual', 'none'],
      default: 'drip',
    },
    crops:   [{ type: mongoose.Schema.Types.ObjectId, ref: 'Crop' }],
    sensors: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Sensor' }],
    alerts:  [{ type: mongoose.Schema.Types.ObjectId, ref: 'Alert' }],
    description: { type: String, maxlength: 500 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Farm', FarmSchema);
