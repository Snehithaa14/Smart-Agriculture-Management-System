/**
 * Alert Model
 * System alerts for critical farm conditions
 */

const mongoose = require('mongoose');

const AlertSchema = new mongoose.Schema(
  {
    title:   { type: String, required: true },
    message: { type: String, required: true },
    type: {
      type: String,
      enum: ['warning', 'critical', 'info', 'success'],
      default: 'warning',
    },
    category: {
      type: String,
      enum: ['water', 'temperature', 'soil', 'pest', 'weather', 'system', 'harvest'],
      default: 'system',
    },
    farm: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farm',
    },
    sensor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Sensor',
    },
    crop: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Crop',
    },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    isRead:     { type: Boolean, default: false },
    isResolved: { type: Boolean, default: false },
    resolvedAt: { type: Date },
    priority: {
      type: String,
      enum: ['low', 'medium', 'high', 'urgent'],
      default: 'medium',
    },
    triggerValue: { type: Number },   // The sensor value that triggered this alert
    threshold:    { type: Number },   // The threshold that was exceeded
  },
  { timestamps: true }
);

module.exports = mongoose.model('Alert', AlertSchema);
