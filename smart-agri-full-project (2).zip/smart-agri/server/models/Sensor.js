/**
 * Sensor Model
 * IoT sensor data: temperature, humidity, soil moisture
 */

const mongoose = require('mongoose');

const ReadingSchema = new mongoose.Schema({
  value:     { type: Number, required: true },
  timestamp: { type: Date, default: Date.now },
  status: {
    type: String,
    enum: ['normal', 'warning', 'critical'],
    default: 'normal',
  },
});

const SensorSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    type: {
      type: String,
      enum: ['temperature', 'humidity', 'soil', 'light', 'rainfall', 'wind'],
      required: true,
    },
    farm: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Farm',
      required: true,
    },
    location: { type: String },   // e.g. "North Field", "Greenhouse A"
    unit: {
      type: String,
      default: function () {
        const units = { temperature: '°C', humidity: '%', soil: '%', light: 'lux', rainfall: 'mm', wind: 'km/h' };
        return units[this.type] || 'unit';
      },
    },
    thresholds: {
      min: { type: Number },
      max: { type: Number },
    },
    currentValue: { type: Number, default: 0 },
    readings: {
      type: [ReadingSchema],
      default: [],
      // Keep only last 100 readings
    },
    isActive: { type: Boolean, default: true },
    batteryLevel: { type: Number, min: 0, max: 100, default: 100 },
    lastPing: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Before saving, auto-trim readings to last 100
SensorSchema.pre('save', function (next) {
  if (this.readings.length > 100) {
    this.readings = this.readings.slice(-100);
  }
  next();
});

module.exports = mongoose.model('Sensor', SensorSchema);
