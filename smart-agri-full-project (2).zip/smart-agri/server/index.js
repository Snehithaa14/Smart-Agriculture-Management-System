/**
 * Smart Agriculture Management System - Entry Point
 * Initializes Express server, connects MongoDB, sets up Socket.IO
 *
 * Two frontend modes:
 *   1. Standalone HTML (default, no build required)
 *      → Serves agrosense-3d.html at http://localhost:5000/agrosense-3d.html
 *   2. React SPA (after running `cd client && npm install && npm run build`)
 *      → Set FRONTEND_MODE=react in .env, then restart server
 */

const express    = require('express');
const http       = require('http');
const path       = require('path');
const { Server } = require('socket.io');
const cors       = require('cors');
const morgan     = require('morgan');
const dotenv     = require('dotenv');
const connectDB  = require('./config/db');
const errorHandler = require('./middleware/errorHandler');

// Load environment variables
dotenv.config();

// Connect to MongoDB
connectDB();

const app    = express();
const server = http.createServer(app);

// Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: ['http://localhost:3000', 'http://localhost:5000'],
    methods: ['GET', 'POST'],
  },
});

// Make io accessible in routes
app.set('io', io);

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({ origin: ['http://localhost:3000', 'http://localhost:5000'], credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(morgan('dev'));

// ─── Static Frontend Serving ──────────────────────────────────────────────────
const FRONTEND_MODE = process.env.FRONTEND_MODE || 'standalone';
const PORT          = process.env.PORT || 5000;

if (FRONTEND_MODE === 'react') {
  // Serve the React build output (run `cd client && npm run build` first)
  app.use(express.static(path.join(__dirname, '../client/build')));
  console.log('Frontend mode: React SPA  -> /client/build');
} else {
  // Default: serve agrosense-3d.html from client/public
  app.use(express.static(path.join(__dirname, '../client/public')));
  console.log(`Frontend mode: Standalone HTML  ->  http://localhost:${PORT}/agrosense-3d.html`);
}

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/users',   require('./routes/userRoutes'));
app.use('/api/farms',   require('./routes/farmRoutes'));
app.use('/api/crops',   require('./routes/cropRoutes'));
app.use('/api/sensors', require('./routes/sensorRoutes'));
app.use('/api/alerts',  require('./routes/alertRoutes'));
app.use('/api/weather', require('./routes/weatherRoutes'));

// Health check
app.get('/api/health', (req, res) => res.json({ status: 'OK', timestamp: new Date() }));

// ─── Catch-all ────────────────────────────────────────────────────────────────
app.get('*', (req, res) => {
  if (FRONTEND_MODE === 'react') {
    res.sendFile(path.join(__dirname, '../client/build/index.html'));
  } else {
    res.redirect('/agrosense-3d.html');
  }
});

// ─── Socket.IO Real-time Events ───────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`Client connected: ${socket.id}`);

  socket.on('join-farm', (farmId) => {
    socket.join(`farm-${farmId}`);
    console.log(`Socket ${socket.id} joined farm-${farmId}`);
  });

  socket.on('disconnect', () => {
    console.log(`Client disconnected: ${socket.id}`);
  });
});

// Simulate real-time sensor data every 10 seconds
setInterval(async () => {
  try {
    const Sensor  = require('./models/Sensor');
    const sensors = await Sensor.find().populate('farm', '_id');
    sensors.forEach((sensor) => {
      const update = {
        sensorId:  sensor._id,
        type:      sensor.type,
        value:     generateSensorValue(sensor.type),
        timestamp: new Date(),
      };
      io.to(`farm-${sensor.farm?._id}`).emit('sensor-update', update);
    });
  } catch (err) {
    // Silently handle if no sensors exist yet
  }
}, 10000);

function generateSensorValue(type) {
  switch (type) {
    case 'temperature': return +(20 + Math.random() * 15).toFixed(1);
    case 'humidity':    return +(40 + Math.random() * 40).toFixed(1);
    case 'soil':        return +(20 + Math.random() * 60).toFixed(1);
    default:            return +(Math.random() * 100).toFixed(1);
  }
}

// ─── Error Handler (must be last) ─────────────────────────────────────────────
app.use(errorHandler);

server.listen(PORT, () => {
  console.log(`\nSmart Agri Server running on port ${PORT}`);
  console.log(`Socket.IO ready for real-time updates\n`);
});
