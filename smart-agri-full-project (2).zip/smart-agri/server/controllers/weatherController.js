/**
 * Weather Controller
 * Simulates weather API for farm locations
 * In production, replace with OpenWeatherMap or similar
 */

const getWeather = async (req, res, next) => {
  try {
    const { location = 'Farm' } = req.query;

    // Simulated current weather
    const conditions = ['Sunny', 'Partly Cloudy', 'Overcast', 'Light Rain', 'Thunderstorm', 'Clear'];
    const icons = ['☀️', '⛅', '☁️', '🌧️', '⛈️', '🌙'];
    const condIdx = Math.floor(Math.random() * conditions.length);

    const current = {
      location,
      temperature: +(22 + Math.random() * 12).toFixed(1),
      feelsLike:   +(20 + Math.random() * 12).toFixed(1),
      humidity:    +(50 + Math.random() * 35).toFixed(0),
      windSpeed:   +(5  + Math.random() * 20).toFixed(1),
      rainfall:    +(Math.random() * 10).toFixed(1),
      condition:   conditions[condIdx],
      icon:        icons[condIdx],
      uvIndex:     Math.floor(Math.random() * 11),
      pressure:    +(1010 + Math.random() * 20 - 10).toFixed(0),
      visibility:  +(5 + Math.random() * 15).toFixed(1),
      timestamp:   new Date(),
    };

    // 7-day forecast
    const forecast = Array.from({ length: 7 }, (_, i) => {
      const idx = Math.floor(Math.random() * conditions.length);
      return {
        day: new Date(Date.now() + i * 86400000).toLocaleDateString('en-US', { weekday: 'short' }),
        high: +(22 + Math.random() * 10).toFixed(0),
        low:  +(12 + Math.random() * 8).toFixed(0),
        condition: conditions[idx],
        icon: icons[idx],
        rainChance: Math.floor(Math.random() * 100),
      };
    });

    // Hourly for next 24 hours
    const hourly = Array.from({ length: 24 }, (_, i) => ({
      hour: `${(new Date().getHours() + i) % 24}:00`,
      temp: +(18 + Math.random() * 16).toFixed(0),
      rain: +(Math.random() * 5).toFixed(1),
    }));

    res.json({ success: true, data: { current, forecast, hourly } });
  } catch (err) {
    next(err);
  }
};

// @desc    Get weather alerts based on conditions
const getWeatherAlerts = async (req, res, next) => {
  try {
    const alerts = [
      { type: 'warning', message: 'Heavy rain expected in 2 days — protect sensitive crops' },
      { type: 'info',    message: 'Optimal planting conditions this weekend' },
    ];
    res.json({ success: true, data: alerts });
  } catch (err) {
    next(err);
  }
};

module.exports = { getWeather, getWeatherAlerts };
