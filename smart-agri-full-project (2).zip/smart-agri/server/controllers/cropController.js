/**
 * Crop Controller
 * Full CRUD for crop management
 */

const Crop = require('../models/Crop');
const Farm = require('../models/Farm');

// @desc    Get all crops (optionally filter by farm)
// @route   GET /api/crops?farmId=xxx
// @access  Private
const getCrops = async (req, res, next) => {
  try {
    const filter = { owner: req.user._id };
    if (req.query.farmId) filter.farm = req.query.farmId;

    const crops = await Crop.find(filter).populate('farm', 'name location');
    res.json({ success: true, count: crops.length, data: crops });
  } catch (err) {
    next(err);
  }
};

// @desc    Get single crop
// @route   GET /api/crops/:id
// @access  Private
const getCrop = async (req, res, next) => {
  try {
    const crop = await Crop.findById(req.params.id).populate('farm', 'name');
    if (!crop) return res.status(404).json({ success: false, message: 'Crop not found' });
    if (crop.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    res.json({ success: true, data: crop });
  } catch (err) {
    next(err);
  }
};

// @desc    Create crop
// @route   POST /api/crops
// @access  Private
const createCrop = async (req, res, next) => {
  try {
    const farm = await Farm.findById(req.body.farm);
    if (!farm) return res.status(404).json({ success: false, message: 'Farm not found' });
    if (farm.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    const crop = await Crop.create({ ...req.body, owner: req.user._id });
    await Farm.findByIdAndUpdate(req.body.farm, { $push: { crops: crop._id } });

    // Emit real-time update
    const io = req.app.get('io');
    io.to(`farm-${req.body.farm}`).emit('crop-added', crop);

    res.status(201).json({ success: true, data: crop });
  } catch (err) {
    next(err);
  }
};

// @desc    Update crop
// @route   PUT /api/crops/:id
// @access  Private
const updateCrop = async (req, res, next) => {
  try {
    let crop = await Crop.findById(req.params.id);
    if (!crop) return res.status(404).json({ success: false, message: 'Crop not found' });
    if (crop.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    crop = await Crop.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });

    const io = req.app.get('io');
    io.to(`farm-${crop.farm}`).emit('crop-updated', crop);

    res.json({ success: true, data: crop });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete crop
// @route   DELETE /api/crops/:id
// @access  Private
const deleteCrop = async (req, res, next) => {
  try {
    const crop = await Crop.findById(req.params.id);
    if (!crop) return res.status(404).json({ success: false, message: 'Crop not found' });
    if (crop.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    await crop.deleteOne();
    await Farm.findByIdAndUpdate(crop.farm, { $pull: { crops: crop._id } });

    res.json({ success: true, message: 'Crop deleted' });
  } catch (err) {
    next(err);
  }
};

module.exports = { getCrops, getCrop, createCrop, updateCrop, deleteCrop };
