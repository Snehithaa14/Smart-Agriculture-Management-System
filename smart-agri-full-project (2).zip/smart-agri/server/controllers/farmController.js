/**
 * Farm Controller
 * Full CRUD operations for farms
 */

const Farm = require('../models/Farm');
const User = require('../models/User');

// @desc    Get all farms for current user
// @route   GET /api/farms
// @access  Private
const getFarms = async (req, res, next) => {
  try {
    const farms = await Farm.find({ owner: req.user._id })
      .populate('crops', 'name status healthScore')
      .populate('sensors', 'name type currentValue unit isActive')
      .populate('alerts', 'title type isRead');

    res.json({ success: true, count: farms.length, data: farms });
  } catch (err) {
    next(err);
  }
};

// @desc    Get single farm
// @route   GET /api/farms/:id
// @access  Private
const getFarm = async (req, res, next) => {
  try {
    const farm = await Farm.findById(req.params.id)
      .populate('crops')
      .populate('sensors')
      .populate({ path: 'alerts', options: { sort: { createdAt: -1 }, limit: 20 } });

    if (!farm) return res.status(404).json({ success: false, message: 'Farm not found' });
    if (farm.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    res.json({ success: true, data: farm });
  } catch (err) {
    next(err);
  }
};

// @desc    Create farm
// @route   POST /api/farms
// @access  Private
const createFarm = async (req, res, next) => {
  try {
    const farm = await Farm.create({ ...req.body, owner: req.user._id });

    // Add farm reference to user
    await User.findByIdAndUpdate(req.user._id, { $push: { farms: farm._id } });

    res.status(201).json({ success: true, data: farm });
  } catch (err) {
    next(err);
  }
};

// @desc    Update farm
// @route   PUT /api/farms/:id
// @access  Private
const updateFarm = async (req, res, next) => {
  try {
    let farm = await Farm.findById(req.params.id);
    if (!farm) return res.status(404).json({ success: false, message: 'Farm not found' });
    if (farm.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    farm = await Farm.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    res.json({ success: true, data: farm });
  } catch (err) {
    next(err);
  }
};

// @desc    Delete farm
// @route   DELETE /api/farms/:id
// @access  Private
const deleteFarm = async (req, res, next) => {
  try {
    const farm = await Farm.findById(req.params.id);
    if (!farm) return res.status(404).json({ success: false, message: 'Farm not found' });
    if (farm.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    await farm.deleteOne();
    await User.findByIdAndUpdate(req.user._id, { $pull: { farms: farm._id } });

    res.json({ success: true, message: 'Farm deleted' });
  } catch (err) {
    next(err);
  }
};

module.exports = { getFarms, getFarm, createFarm, updateFarm, deleteFarm };
