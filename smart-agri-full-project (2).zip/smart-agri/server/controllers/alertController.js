/**
 * Alert Controller
 * Manage system notifications and alerts
 */

const Alert = require('../models/Alert');

const getAlerts = async (req, res, next) => {
  try {
    const filter = { owner: req.user._id };
    if (req.query.unread === 'true') filter.isRead = false;
    if (req.query.farmId) filter.farm = req.query.farmId;

    const alerts = await Alert.find(filter)
      .sort({ createdAt: -1 })
      .limit(50)
      .populate('farm', 'name')
      .populate('sensor', 'name type');

    res.json({ success: true, count: alerts.length, data: alerts });
  } catch (err) { next(err); }
};

const createAlert = async (req, res, next) => {
  try {
    const alert = await Alert.create({ ...req.body, owner: req.user._id });
    const io = req.app.get('io');
    if (req.body.farm) io.to(`farm-${req.body.farm}`).emit('new-alert', alert);
    res.status(201).json({ success: true, data: alert });
  } catch (err) { next(err); }
};

const markRead = async (req, res, next) => {
  try {
    await Alert.findByIdAndUpdate(req.params.id, { isRead: true });
    res.json({ success: true, message: 'Alert marked as read' });
  } catch (err) { next(err); }
};

const markAllRead = async (req, res, next) => {
  try {
    await Alert.updateMany({ owner: req.user._id, isRead: false }, { isRead: true });
    res.json({ success: true, message: 'All alerts marked as read' });
  } catch (err) { next(err); }
};

const resolveAlert = async (req, res, next) => {
  try {
    await Alert.findByIdAndUpdate(req.params.id, { isResolved: true, resolvedAt: new Date() });
    res.json({ success: true, message: 'Alert resolved' });
  } catch (err) { next(err); }
};

const deleteAlert = async (req, res, next) => {
  try {
    await Alert.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Alert deleted' });
  } catch (err) { next(err); }
};

module.exports = { getAlerts, createAlert, markRead, markAllRead, resolveAlert, deleteAlert };
