/**
 * Sensor Controller
 * CRUD + real-time readings for IoT sensors
 */

const Sensor = require('../models/Sensor');
const Alert  = require('../models/Alert');
const Farm   = require('../models/Farm');

const getSensors = async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.farmId) filter.farm = req.query.farmId;

    const sensors = await Sensor.find(filter).populate('farm', 'name owner');
    const owned = sensors.filter(s => s.farm?.owner?.toString() === req.user._id.toString());
    res.json({ success: true, count: owned.length, data: owned });
  } catch (err) { next(err); }
};

const getSensor = async (req, res, next) => {
  try {
    const sensor = await Sensor.findById(req.params.id).populate('farm', 'name owner');
    if (!sensor) return res.status(404).json({ success: false, message: 'Sensor not found' });
    res.json({ success: true, data: sensor });
  } catch (err) { next(err); }
};

const createSensor = async (req, res, next) => {
  try {
    const sensor = await Sensor.create(req.body);
    await Farm.findByIdAndUpdate(req.body.farm, { $push: { sensors: sensor._id } });
    res.status(201).json({ success: true, data: sensor });
  } catch (err) { next(err); }
};

// @desc    Add a new reading to a sensor
// @route   POST /api/sensors/:id/readings
const addReading = async (req, res, next) => {
  try {
    const { value } = req.body;
    const sensor = await Sensor.findById(req.params.id);
    if (!sensor) return res.status(404).json({ success: false, message: 'Sensor not found' });

    let status = 'normal';
    if (sensor.thresholds.min && value < sensor.thresholds.min) status = 'critical';
    else if (sensor.thresholds.max && value > sensor.thresholds.max) status = 'critical';

    sensor.readings.push({ value, status });
    sensor.currentValue = value;
    sensor.lastPing = new Date();
    await sensor.save();

    // Auto-generate alert if critical
    if (status === 'critical') {
      const alert = await Alert.create({
        title: `${sensor.type.toUpperCase()} Alert`,
        message: `Sensor "${sensor.name}" reading ${value}${sensor.unit} exceeds safe threshold`,
        type: 'critical',
        category: sensor.type,
        farm: sensor.farm,
        sensor: sensor._id,
        owner: req.user._id,
        triggerValue: value,
        threshold: value < sensor.thresholds.min ? sensor.thresholds.min : sensor.thresholds.max,
      });

      const io = req.app.get('io');
      io.to(`farm-${sensor.farm}`).emit('new-alert', alert);
    }

    res.json({ success: true, data: sensor });
  } catch (err) { next(err); }
};

const updateSensor = async (req, res, next) => {
  try {
    const sensor = await Sensor.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json({ success: true, data: sensor });
  } catch (err) { next(err); }
};

const deleteSensor = async (req, res, next) => {
  try {
    await Sensor.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: 'Sensor deleted' });
  } catch (err) { next(err); }
};

module.exports = { getSensors, getSensor, createSensor, addReading, updateSensor, deleteSensor };
